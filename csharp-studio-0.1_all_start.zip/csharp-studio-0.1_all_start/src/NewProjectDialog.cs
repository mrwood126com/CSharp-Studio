///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.IO;

namespace CSharpStudio {

public class NewProjectDialog : ModalDialog {
	Project Project_ = null;
		
        public NewProjectDialog (Gtk.Window parent) : base (parent, "new_project_dialog")
        {
	}

	protected override bool TransferDataToWindow ()
	{
		Gtk.Entry nameEntry = (Gtk.Entry)GladeXml_ ["new_project_dialog_name_entry"];
		nameEntry.Text = "New Project";

		return true;
	}
	
	protected override bool TransferDataFromWindow ()
	{
		Project project = new Project ();
		string tmp;
		
		Gtk.Entry nameEntry = (Gtk.Entry)GladeXml_ ["new_project_dialog_name_entry"];
		tmp = nameEntry.Text.Trim ();
		if (tmp == String.Empty) {
			ShowError ("The project name could not be empty.");
			return false;
		}
		project.Name = tmp;

		Gnome.FileEntry topFolderEntry = (Gnome.FileEntry)GladeXml_ ["new_project_dialog_top_folder_fileentry"];
		tmp = topFolderEntry.GtkEntry.Text.Trim (); // todo: use GetFullPath (true); instead, now it asserts
		if (tmp == String.Empty) {
			ShowError ("The top project folder could not be empty.");
			return false;
		} else {
			DirectoryInfo di = new DirectoryInfo (tmp);
			if (!di.Exists) {
				ShowError ("The top project folder must exist and be a folder.");
				return false;
			}
		}
		project.TopProjectFolder = tmp;
		
		Gnome.FileEntry filenameEntry = (Gnome.FileEntry)GladeXml_ ["new_project_dialog_filename_fileentry"];
		tmp = filenameEntry.GtkEntry.Text.Trim (); // todo: use GetFullPath (false); instead, now it asserts
		if (tmp == String.Empty) {
			ShowError ("The top project filename could not be empty.");
			return false;
		} else {
			FileInfo fi = new FileInfo (tmp);
			if (fi.Exists) {
				MessageDialog dialog = new MessageDialog (Studio.MainWindow, DialogFlags.DestroyWithParent, 
						    MessageType.Warning, ButtonsType.YesNo, 
						    "The file already exists. Overwrite?");
				if ((ResponseType)dialog.Run () != ResponseType.Yes) {
					dialog.Destroy ();
					return false;
				}	
				dialog.Destroy ();
			}		
		}
		project.Filename = tmp;

		Gtk.TextView descriptionText = (Gtk.TextView)GladeXml_ ["new_project_dialog_description_textview"];
		if (descriptionText.Buffer != null) {
			project.Description = descriptionText.Buffer.Text;
		}
		
		project.IncludedFiles 	= new string[] { "*" };
		project.ExcludedFiles 	= new string[] { "CVS", ".cvsignore", "*.tmp", "*.bak", "*.cache" };

		project.TopBuildFolder 	= project.TopProjectFolder;
		project.ExecuteTarget 	= Path.ChangeExtension (Path.Combine (project.TopProjectFolder, project.Name), "exe");

		Project_ = project;
		return true;
	}
		
	public Project Project {	
		get {
			return Project_;
		}		
	}
}

}
