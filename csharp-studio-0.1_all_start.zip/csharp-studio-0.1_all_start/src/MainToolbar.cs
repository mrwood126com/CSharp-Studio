///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using GConf;
using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.IO;


namespace CSharpStudio {

public class MainToolbar {
	Glade.XML GladeXml_ = null;
	Toolbar Toolbar_ = null;
		
        public MainToolbar (Toolbar toolbar)
        {
		Toolbar_ 		= toolbar;
		Toolbar_.Tooltips 	= true;
		GladeXml_ 		= Glade.XML.GetWidgetTree (Toolbar_);
		Settings.ToolbarSettingsChanged += new NotifyEventHandler (toolbar_settings_changed_cb);
	}

	public void UpdateUI ()
	{
		ShowItem ("new_button",  Settings.ShowFileButtons);
		ShowItem ("open_button",  Settings.ShowFileButtons);
		ShowItem ("save_button",  Settings.ShowFileButtons);
		ShowItem ("save_all_button",  Settings.ShowFileButtons);
		ShowItem ("print_button",  Settings.ShowFileButtons);

		ShowItem ("undo_button",  Settings.ShowEditButtons);
	    	ShowItem ("redo_button",  Settings.ShowEditButtons);
	    	ShowItem ("cut_button",  Settings.ShowEditButtons);
		ShowItem ("copy_button",  Settings.ShowEditButtons);
		ShowItem ("paste_button",  Settings.ShowEditButtons);

		ShowItem ("build_button",  Settings.ShowBuildButtons);
		ShowItem ("rebuild_button",  Settings.ShowBuildButtons);
		ShowItem ("execute_button",  Settings.ShowBuildButtons);

		ShowItem ("find_hbox",  false && Settings.ShowFindButtons); // todo: toolbar search entry box
		ShowItem ("find_files_button",  Settings.ShowFindButtons);
		
		Studio.MainMenu.ActivateItem ("view_toolbar_file", Settings.ShowFileButtons);
		Studio.MainMenu.ActivateItem ("view_toolbar_edit", Settings.ShowEditButtons);
		Studio.MainMenu.ActivateItem ("view_toolbar_build", Settings.ShowBuildButtons);
		Studio.MainMenu.ActivateItem ("view_toolbar_find", Settings.ShowFindButtons);
	}
	
	public Widget GetItem (string name)
	{
		return (Widget)GladeXml_ [name];
    	}

	public void ShowItem (string name, bool show) 
	{
		try {
			Widget item = GetItem (name);
			if (item.Visible != show) {
				item.Visible = show;
			}
		} catch (Exception exception) {
			Console.WriteLine ("MainToolbar.ShowItem ({0}): exception {1}", name, exception.GetType().FullName);
		}
	}
		
	public void EnableItem (string name, bool enable) 
	{
		try {
			Widget item = GetItem (name);
			if (item.Sensitive != enable) {
				item.Sensitive = enable;
			}
		} catch (Exception exception) {
			Console.WriteLine ("MainToolbar.ShowItem ({0}): exception {1}", name, exception.GetType().FullName);
		}
	}
	
	public Toolbar Toolbar {
		get {
			return Toolbar_;
		}
	}

	void toolbar_settings_changed_cb (object obj, NotifyEventArgs args)
	{
		// Console.WriteLine ("toolbar_settings_changed_cb");
		try {
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}
}

}
