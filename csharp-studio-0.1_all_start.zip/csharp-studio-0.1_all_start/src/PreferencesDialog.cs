///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.IO;

namespace CSharpStudio {

public class PreferencesDialog : ModalDialog {
	Project Project_ = null;
	
	Gtk.Notebook Notebook_;
	
	// Save tab
	Gtk.CheckButton AutoSaveProjectCheckButton_;
	Gtk.CheckButton AutoSaveFilesCheckButton_;
		
	// Editor tab
	Gtk.CheckButton ShowLineNumbersCheckButton_;
	Gtk.CheckButton EnableAutoIndentCheckButton_;
	Gtk.CheckButton EnableSmartHomeEndCheckButton_;
	Gnome.FontPicker EditorFontPicker_;

        public PreferencesDialog (Gtk.Window parent) : base (parent, "preferences_dialog")
        {
		Notebook_ 			= (Gtk.Notebook)GladeXml_ ["preferences_dialog_notebook"];
		
		// Save tab
		AutoSaveProjectCheckButton_ 	= (Gtk.CheckButton)GladeXml_ ["preferences_dialog_autosave_project_checkbutton"];
		AutoSaveFilesCheckButton_ 	= (Gtk.CheckButton)GladeXml_ ["preferences_dialog_autosave_files_checkbutton"];

		// Editor tab
		ShowLineNumbersCheckButton_ 	= (Gtk.CheckButton)GladeXml_ ["preferences_dialog_editor_show_line_numbers_checkbutton"];
		EnableAutoIndentCheckButton_ 	= (Gtk.CheckButton)GladeXml_ ["preferences_dialog_editor_enable_auto_indent_checkbutton"];
		EnableSmartHomeEndCheckButton_ 	= (Gtk.CheckButton)GladeXml_ ["preferences_dialog_editor_enable_smart_home_end_checkbutton"];
		EditorFontPicker_				= (Gnome.FontPicker)GladeXml_ ["preferences_dialog_editor_fontpicker"];	
	}

	protected override bool TransferDataToWindow ()
	{
		Notebook_.CurrentPage			= Settings.PreferencesDialogTab;
		
		// Save tab
		AutoSaveProjectCheckButton_.Active	= Settings.AutoSaveProject;
		AutoSaveFilesCheckButton_.Active 	= Settings.AutoSaveFiles;
    
		// Editor tab
		ShowLineNumbersCheckButton_.Active	= Settings.ShowLineNumbers;
		EnableAutoIndentCheckButton_.Active		= Settings.EnableAutoIndent;
		EnableSmartHomeEndCheckButton_.Active= Settings.EnableSmartHomeEnd;
		EditorFontPicker_.FontName				= Settings.EditorFontName;
		return true;
	}
	
	protected override bool TransferDataFromWindow ()
	{
		Settings.PreferencesDialogTab 	= Notebook_.CurrentPage;

		// Save tab
		Settings.AutoSaveProject 		= AutoSaveProjectCheckButton_.Active;
		Settings.AutoSaveFiles 			= AutoSaveFilesCheckButton_.Active;

		// Editor tab
		Settings.ShowLineNumbers		= ShowLineNumbersCheckButton_.Active;
		Settings.EnableAutoIndent		= EnableAutoIndentCheckButton_.Active;
		Settings.EnableSmartHomeEnd	= EnableSmartHomeEndCheckButton_.Active;
		Settings.EditorFontName		= EditorFontPicker_.FontName;
		
		return true;
	}
}

}
