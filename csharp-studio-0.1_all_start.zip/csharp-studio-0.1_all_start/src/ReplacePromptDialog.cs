///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.IO;

namespace CSharpStudio {

public class ReplacePromptDialog : ModalDialog {
	Gtk.Label MessageLabel_;
	
        public ReplacePromptDialog (Gtk.Window parent) : base (parent, "replace_prompt_dialog")
        {
        	MessageLabel_ = (Gtk.Label)GladeXml_ ["replace_prompt_dialog_message_label"];
	}
	
	protected override bool TransferDataToWindow ()
	{
		MessageLabel_.Text = String.Format (MessageLabel_.Text, Settings.FindReplaceReplaceString);
		return true;
	}
	
	protected override bool TransferDataFromWindow ()
	{
		if (Response_ == ResponseType.Apply) {
			Settings.FindRepacePrompt = false;
		}
		return true;
	}
}

}
