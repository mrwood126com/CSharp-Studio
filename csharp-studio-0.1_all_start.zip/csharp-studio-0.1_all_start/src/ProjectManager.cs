///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using GConf;
using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.Collections;
using System.IO;

namespace CSharpStudio {

public class ProjectManager
{
	Glade.XML GladeXml_;
	Notebook Notebook_;
	ArrayList Views_;

	ProjectFilesView FilesView_;

	ProjectFilesList FilesList_ = null;
	int FilesListPos_ = 0;
	
        public ProjectManager (Notebook notebook) 
        {
		GladeXml_ 	= Glade.XML.GetWidgetTree (notebook);
		Notebook_ 	= notebook;

		Views_ 		= new ArrayList ();
		
		// todo: we probably can try to automaticaly
		// get the tab position in notebook
		// but for now the order is important here!
		FilesView_ = new ProjectFilesView ( (TreeView)GladeXml_ ["main_window_project_files_treeview"]);
		Views_.Add (FilesView_);
	}

	public void UpdateUI ()
	{
		// project menu
		Studio.MainMenu.EnableItem ("project_new", ProjectLoaded || Studio.Project == null);
		Studio.MainMenu.EnableItem ("project_open", ProjectLoaded || Studio.Project == null);
		Studio.MainMenu.EnableItem ("project_edit", ProjectLoaded);
		Studio.MainMenu.EnableItem ("project_reload", ProjectLoaded && Studio.Project != null);
		Studio.MainMenu.EnableItem ("project_save", ProjectLoaded && !Settings.AutoSaveProject && Studio.Project.Modified);
		Studio.MainMenu.EnableItem ("project_close", ProjectLoaded);
		Studio.MainMenu.EnableItem ("project_new_folder", ProjectLoaded);
		Studio.MainMenu.EnableItem ("project_add_folder", ProjectLoaded);
		Studio.MainMenu.EnableItem ("project_remove_folder", ProjectLoaded);
		Studio.MainMenu.EnableItem ("project_add_file", ProjectLoaded);
		Studio.MainMenu.EnableItem ("project_remove_file", ProjectLoaded);
	}	

	public void ReloadProject ()
	{
		FilesView_.Clear ();

		if (Studio.Project != null) {
			FilesList_ = new ProjectFilesList (Studio.Project.TopProjectFolder, Studio.Project.IncludedFiles, Studio.Project.ExcludedFiles);
			FilesListPos_ = 0;
			
			GLib.Idle.Add (new GLib.IdleHandler (update_view_cb));
			FilesList_.Start ();
		} else {
			FilesList_ = null;
			FilesListPos_ = 0;
		}
		Studio.UpdateUI ();
	}
    
	public ProjectFile GetItem (TreePath path)
	{
		if (Views_ [Notebook_.CurrentPage] == FilesView_) {
			return FilesView_.GetItem (path);
		}
		
		return null;
	}

	bool update_view_cb ()
	{
		try {
			if (Studio.Project == null) {
				return false;
			}
			
			for (int i = 0; i < 50 && FilesListPos_ < FilesList_.FilesCount; i++) {
				ProjectFile file = FilesList_.GetFile(FilesListPos_++);
				Studio.MainAppBar.SetStatus (String.Format ("Loading folder {0}", file.Parent));
				FilesView_.AddFile (file, FilesList_);
			}
			if (ProjectLoaded) {
				Studio.MainAppBar.SetStatus (String.Empty);
				Studio.UpdateUI ();
			} 
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		return !ProjectLoaded;
	}

	public bool ProjectLoaded {
		get {
			return FilesList_ != null && FilesList_.IsFinished && FilesListPos_ >= FilesList_.FilesCount;
		}
	}	
	
	public bool HasFocus 
	{
		get {
			Widget widget = (Widget) Views_ [Notebook_.CurrentPage];
			return (widget != null) ? widget.HasFocus : false;
		}
	}
	
	public ProjectFilesView FilesView
	{
		get {
			return FilesView_;
		}
	}
}


}
