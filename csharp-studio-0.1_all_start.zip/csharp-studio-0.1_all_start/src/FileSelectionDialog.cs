///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.IO;

namespace CSharpStudio {

public class FileSelectionDialog : ModalDialog {
	string Title_;
	string Filename_;
	FileAccess Access_;
	
	bool SelectFolder_ = false;
	bool SelectMultiple_ = false;
	bool MustExist_ = false;
	
	FileSelection FileSelectionDialog_;
	
	
        public FileSelectionDialog (Gtk.Window parent, string title, FileAccess access, string filename) : 
		base (parent, "fileselection_dialog")
        {
		FileSelectionDialog_ 	= (FileSelection)Dialog_;
		Title_			= title;
		Filename_		= filename;
		Access_			= access;
	
		switch (Access_) {
		    case FileAccess.Read:
			    MustExist = true;
			    SelectMultiple = true;
			    break;
		    case FileAccess.ReadWrite:
			    MustExist = true;
			    SelectMultiple = true;
		    	    break;
		    case FileAccess.Write:
			    MustExist = false;
			    SelectMultiple = false;
			    break;
		}
	}
	
	protected override bool TransferDataToWindow ()
	{
		FileSelectionDialog_.Title 		= Title_;
		FileSelectionDialog_.Filename		= Filename_;
		FileSelectionDialog_.SelectMultiple	= SelectMultiple_;
		
		return true;
	}
	
	protected override bool TransferDataFromWindow ()
	{
		// todo: check that file exists, etc.
		Filename_				= FileSelectionDialog_.Filename;
		return true;
	}
	
	public string Filename 
	{
		get {
			return Filename_;
		}
		
		set {
			Filename_ = value;
		}	
	}
	
	public bool SelectMultiple 
	{
		set {
			SelectMultiple_ = value;
		}
	}

	public bool SelectFolder 
	{
		set {
			SelectFolder_ = value;
		}
	}

	public bool MustExist 
	{
		get {
			return MustExist_;
		}
		
		set {
			MustExist_ = value;
		}
	}
}

}
