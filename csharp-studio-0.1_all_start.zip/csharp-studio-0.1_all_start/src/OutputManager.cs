///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.Collections;
using System.IO;

namespace CSharpStudio {

public class OutputManager {
	Glade.XML GladeXml_;
	Notebook Notebook_;
	ArrayList Views_;

	OutputView ExecuteOutput_;
	OutputView BuildOutput_;
	OutputView FindOutput_;
	
        public OutputManager (Notebook notebook) 
        {
		GladeXml_ = Glade.XML.GetWidgetTree (notebook);
		Notebook_ = notebook;
		Views_ = new ArrayList ();
		
		// todo: we probably can try to automaticaly
		// get the tab position in notebook
		// but for now the order is important here!
		ExecuteOutput_ = new OutputView ( (TextView)GladeXml_ ["main_window_output_execute_textview"], 0);
		Views_.Add (ExecuteOutput_);
		BuildOutput_ = new OutputView ( (TextView)GladeXml_ ["main_window_output_build_textview"], 1);
		Views_.Add (BuildOutput_);
		FindOutput_ = new OutputView ( (TextView)GladeXml_ ["main_window_output_find_textview"], 2);
		Views_.Add (FindOutput_);
	}

	public void ReloadProject ()
	{
		ExecuteOutput_.Clear ();
		BuildOutput_.Clear ();
	}
	
    
	public void UpdateUI ()
	{
		OutputView view = Current;	
	
		Studio.MainMenu.EnableItem ("project_build", Studio.Project != null && !BuildOutput_.IsRunning);
		Studio.MainMenu.EnableItem ("project_build_clean", Studio.Project != null && !BuildOutput_.IsRunning);
		Studio.MainMenu.EnableItem ("project_rebuild", Studio.Project != null && !BuildOutput_.IsRunning);
		Studio.MainMenu.EnableItem ("project_execute", Studio.Project != null && !BuildOutput_.IsRunning);

		Studio.MainToolbar.EnableItem ("build_button", Studio.Project != null && !BuildOutput_.IsRunning); 
		Studio.MainToolbar.EnableItem ("rebuild_button", Studio.Project != null && !BuildOutput_.IsRunning); 
		Studio.MainToolbar.EnableItem ("execute_button", Studio.Project != null && !ExecuteOutput_.IsRunning); 
		Studio.MainToolbar.EnableItem ("find_files_button", !BuildOutput_.IsRunning); 

		if (HasFocus) {		
			view.UpdateUI ();
		}
		
	}
	
	public void Show (OutputView view) {
		Notebook_.CurrentPage = view.Pos;
	}
	
	public void Copy (Clipboard clipboard) 
	{
		if (HasFocus) {
			Current.Copy (clipboard);
		}
	}
	
	public OutputView Current {
		get {
			return (Notebook_.CurrentPage >= 0) ? (OutputView)Views_ [Notebook_.CurrentPage] : null;
		}
	}

	public bool HasFocus {
		get {
			return Current != null && Current.HasFocus;
		}
	}

	public OutputView Execute {
		get {
			return ExecuteOutput_;
		}
	}
	
	public OutputView Build {
		get {
			return BuildOutput_;
		}
	}

	public OutputView Find {
		get {
			return FindOutput_;
		}
	}
}

}
