///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
//   
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.IO;
using System.Drawing;
using System.Runtime.InteropServices;

namespace CSharpStudio {

public class Studio  {
	static Studio Studio_ = null;
	
	Project Project_;
	Glade.XML GladeXml_;
	App MainWindow_;
	
	MainMenu MainMenu_;
	MainToolbar MainToolbar_;
	MainAppBar MainAppBar_;
	
	ProjectManager ProjectManager_;
	FilesManager FilesManager_; 
	OutputManager OutputManager_;
	
	public static int Main (string[] args)
	{
		try {
			Program kit = new Program (Defines.Package, Defines.Version, Modules.UI, args);
			// Gtk.Rc.Parse (Defines.RcFile);
			
			// need to register: we use non-standard assembly name
			ObjectManager.RegisterType ("GtkSourceLanguage", "Gtk.SourceLanguage", "gtk-sourceview-sharp");
			ObjectManager.RegisterType ("GtkSourceBuffer", "Gtk.SourceBuffer", "gtk-sourceview-sharp");

			Studio_ = new Studio ();

			// create new project
			if (args != null && args.Length == 1) {
				try {
					Studio_.AdoptProject (new Project (args [0]), true);
					Studio_.FilesManager_.OpenFiles (Studio_.Project_.OpenedFiles);
    				} catch (System.Xml.XmlException exception) {
					Studio.ShowError (String.Format ("The selected file does not contain a valid project file."));
				} catch (System.IO.FileNotFoundException exception) {
					Studio.ShowError (exception.Message);
				} catch (Exception exception) {
					Studio.ShowExceptionError (exception);
				}
			}
			Studio.UpdateUI ();
		
			kit.Run ();
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		return 0;
	}
	
	public Studio ()
	{
		Project_ = null;

		// prepare UI
		GladeXml_ = new Glade.XML (Defines.GladeFile, "main_window", null);
		GladeXml_.Autoconnect (this);
		MainWindow_ = (App) GladeXml_ ["main_window"];
		
		MainMenu_ = new MainMenu ((MenuBar) GladeXml_ ["main_window_menubar"]);
		MainToolbar_ = new MainToolbar ((Toolbar) GladeXml_ ["main_window_toolbar"]);
		MainAppBar_ = new MainAppBar ((AppBar) GladeXml_ ["main_window_appbar"]);
		
		ProjectManager_ = new ProjectManager ((Notebook) GladeXml_ ["main_window_project_notebook"]);
		FilesManager_ = new FilesManager ((Notebook) GladeXml_ ["main_window_files_notebook"]);
		OutputManager_ = new OutputManager ((Notebook) GladeXml_ ["main_window_output_notebook"]);
		
		// register popup menus
		MainMenu_.RegisterPopupMenu ("project_files_project_popup_menu", this);
		MainMenu_.RegisterPopupMenu ("project_files_folder_popup_menu", this);
		MainMenu_.RegisterPopupMenu ("project_files_file_popup_menu", this);
		
		// restore UI		
		Settings.RestoreWindowSize (MainWindow_, "main_window");
		Settings.RestorePanedPosition ((Paned) GladeXml_ ["main_window_hpaned"], "main_window_hpaned");
		Settings.RestorePanedPosition ((Paned) GladeXml_ ["main_window_vpaned"], "main_window_vpaned");

		MainWindow_.Show ();		
	}
		
	
	public bool EnsureProjectIsSaved ()
	{
		bool res = true;
	        if (Modified) {
			YesNoCancelDialog dialog = new YesNoCancelDialog (MainWindow_, 
						"Not all files have not been saved. Save before closing?",
						"C# Studio");
			switch (dialog.Run()) {
			    case ResponseType.Yes: 
				if (Project_ != null) {
					Project_.Save ();
				}
				res = FilesManager_.SaveAll (true);
				break;
			    case ResponseType.No: 
				break;
			    case ResponseType.Cancel: 
				res = false;
				break;
			}
		}
		return res;
	}
	
	public bool Modified 
	{
		get {
			return (Project_ != null && Project_.Modified) || FilesManager_.Modified;
		}
	}
	

	public void AdoptProject (Project project, bool reloadFiles) 
	{
		Project_ = project;
		Project_.Modified = true; // force save
		Settings.LastOpenedProject = Project_.Filename;
				
		// update ui
		FilesManager_.ReloadProject (reloadFiles);
		OutputManager_.ReloadProject ();
		ProjectManager_.ReloadProject ();
				
		// todo: requires new gtk-sharp
		if (Project_ != null) {
			Gnome.Window.ToplevelSetTitle (MainWindow_, Project_.Name, Defines.PackageTitle, null);
			// MainWindow_.Title = String.Format ("{0}: {1}", Project_.Name, Defines.PackageTitle);
		} else {
			Gnome.Window.ToplevelSetTitle (MainWindow_, null, Defines.PackageTitle, null);
			// MainWindow_.Title = Defines.PackageTitle;
		}
	}

	static public Studio MainStudio 
	{
		get {
			return Studio_;
		}
	}
		
	static public Gtk.Window MainWindow 
	{
		get {
			return Studio_.MainWindow_;
		}
	}

	static public MainMenu MainMenu 
	{
		get {
			return Studio_.MainMenu_;
		}
	}

	static public MainToolbar MainToolbar 
	{
		get {
			return Studio_.MainToolbar_;
		}
	}

	static public Project Project 
	{
		get {
			return (Studio_ != null) ? Studio_.Project_ : null;
		}
	}
	
	static public string TopFolder 
	{
		get {
			return (Project != null) ? Project.TopProjectFolder : "./";
		}
	}

	static public MainAppBar MainAppBar 
	{
		get {
			return Studio_.MainAppBar_;
		}
	}

	static public void UpdateUI ()
	{
		try { 
			Studio_.MainToolbar_.UpdateUI ();
			Studio_.UpdateMenuAndToolbar ();
			
			Studio_.ProjectManager_.UpdateUI();
			Studio_.FilesManager_.UpdateUI(); 
			Studio_.OutputManager_.UpdateUI ();
 
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
	}

	void UpdateMenuAndToolbar ()
	{
		// file menu
		MainMenu_.EnableItem ("file_save_all", Modified);
		MainToolbar_.EnableItem ("save_all_button", Modified);

		// edit menu		
		if (!FilesManager_.HasFocus && !OutputManager_.HasFocus) { 
	    		MainMenu_.EnableItem ("edit_undo", false);
			MainMenu_.EnableItem ("edit_redo", false);

			MainMenu_.EnableItem ("edit_cut", false);
			MainMenu_.EnableItem ("edit_copy", false);
			MainMenu_.EnableItem ("edit_paste", false);
			MainMenu_.EnableItem ("edit_clear", false);

	    		MainMenu_.EnableItem ("edit_find", false);
			MainMenu_.EnableItem ("edit_replace", false);

			MainToolbar_.EnableItem ("undo_button", false);
			MainToolbar_.EnableItem ("redo_button", false);
		
			MainToolbar_.EnableItem ("cut_button", false);
			MainToolbar_.EnableItem ("copy_button", false);
			MainToolbar_.EnableItem ("paste_button", false);
		}
	}
	
	static public void GotoLine (string filename, int line)
	{
		Studio_.FilesManager_.GotoLine (filename, line);
	}
	
	static public void OpenFile (string filename)
	{
		try {
			Studio_.FilesManager_.OpenFile (filename);
		} catch (FileNotFoundException exception) {
			Studio.ShowError (exception.Message);
		} catch (System.UnauthorizedAccessException exception) {
			Studio.ShowError (exception.Message);
		} 	
	}

	static public void OpenProject (string filename)
	{
		try {
			if (Project != null && Project.Filename == filename) {
				return;
			} 
			if (!Studio_.EnsureProjectIsSaved ()) {
				return;
			}
			if (!Studio_.FilesManager_.CloseAllFiles ()) {
				return;
			}
			Studio_.AdoptProject (new Project (filename), true); 
		} catch (FileNotFoundException exception) {
			Studio.ShowError (exception.Message);
		} catch (System.UnauthorizedAccessException exception) {
			Studio.ShowError (exception.Message);
		} 	
	}
		
	//
	// Show errors
	//
	static public void ShowError (string msg)
	{
		MessageDialog dialog = new MessageDialog (MainWindow, DialogFlags.DestroyWithParent, 
				    MessageType.Error, ButtonsType.Ok, msg);
		dialog.Run();
		dialog.Destroy();
	}

	static public void ShowExceptionError (Exception exception)
	{
		Console.WriteLine ("Exception {0}: {1}\n{2}", exception.GetType().FullName, exception.Message, exception.StackTrace);
		ExceptionDialog dialog = new ExceptionDialog (Studio.MainWindow, exception.GetType().FullName, exception.Message, exception.StackTrace);
		switch (dialog.Run()) {
		case ResponseType.Yes:
			// todo: force save files 
			if (Studio_.Project_ != null) { 
				Studio_.Project_.Save ();
			}
			Studio_.FilesManager_.SaveAll (true);
			// todo: report error
			break;
		case ResponseType.No:
			// todo: force sve files
			if (Studio_.Project_ != null) { 
				Studio_.Project_.Save ();
			}
			Studio_.FilesManager_.SaveAll (true);
			break;
		}
	}
		
	static public void ShowTodoError(string func)
	{	
		Studio.ShowError (String.Format("TODO: {0} is not implemented yet", func));
	}

	//
	// callbacks 
	//
	void on_layout_changed_cb (object obj, EventArgs args)
	{	
		try {
			// Console.WriteLine ("on_layout_changed_cb");
			Settings.SaveWindowSize (MainWindow_, "main_window");
			Settings.SavePanedPosition ((Paned) GladeXml_ ["main_window_hpaned"], "main_window_hpaned");
			Settings.SavePanedPosition ((Paned) GladeXml_ ["main_window_vpaned"], "main_window_vpaned");
			if (Project_ != null) {
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
	}

	void on_focus_in_cb (object o, FocusInEventArgs args)
	{		
		try {
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}

	void on_focus_out_cb (object o, FocusOutEventArgs args)
	{		
		try {
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}

	void on_window_delete_event_cb (object obj, DeleteEventArgs args)
	{
		try {
			SignalArgs sa = (SignalArgs) args;
			if (obj == MainWindow_ && EnsureProjectIsSaved()) {
				Application.Quit();
				sa.RetVal = true;
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
	}


	// menu cb		
	void on_file_new_cb (object o, EventArgs args)
	{
		try {
			FilesManager_.OpenFile (String.Empty);
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}

	void on_file_open_cb (object o, EventArgs args)
	{
		try {
			FilesManager_.OpenFile ();
		} catch (FileNotFoundException exception) {
			Studio.ShowError (exception.Message);
		} catch (System.UnauthorizedAccessException exception) {
			Studio.ShowError (exception.Message);
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}
	
	void on_file_save_cb (object o, EventArgs args)
	{
		try {
			FilesManager_.SaveFile ();
		} catch (System.IO.FileNotFoundException exception) {
			Studio.ShowError (exception.Message);
		} catch (System.UnauthorizedAccessException exception) {
			Studio.ShowError (exception.Message);
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}

	void on_file_save_all_cb (object o, EventArgs args)
	{
		try {
			if (Project_ != null) {
				Project_.Save ();
			}
			FilesManager_.SaveAll (true);
		} catch (System.IO.FileNotFoundException exception) {
			Studio.ShowError (exception.Message);
		} catch (System.UnauthorizedAccessException exception) {
			Studio.ShowError (exception.Message);
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}

	void on_file_save_as_cb (object o, EventArgs args)
	{
		try {
			FilesManager_.SaveAsFile ();
		} catch (System.IO.FileNotFoundException exception) {
			Studio.ShowError (exception.Message);
		} catch (System.UnauthorizedAccessException exception) {
			Studio.ShowError (exception.Message);
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}

	void on_print_cb (object o, EventArgs args)
	{
		try {
		    	Studio.ShowTodoError ("print_cb");
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_print_setup_cb (object o, EventArgs args)
	{
		try {
	    		Studio.ShowTodoError ("print_setup_cb");
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_close_cb (object o, EventArgs args)
	{
		try {
		    	FilesManager_.CloseFile ();
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}


	void on_quit_cb (object o, EventArgs args)
	{
		try {
			if (EnsureProjectIsSaved ()) {
		    		Application.Quit ();
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	// edit menu
	public static Atom CLIPBOARD = Atom.Intern("CLIPBOARD", false);
	void on_copy_cb (object o, EventArgs args)
	{
		try {
			if (FilesManager_.HasFocus) {
				FilesManager_.Copy (Clipboard.Get(CLIPBOARD));
			} else if (OutputManager_.HasFocus) {
				OutputManager_.Copy (Clipboard.Get(CLIPBOARD));
			} else {
	    			Studio.ShowTodoError ("copy_cb");
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_cut_cb (object o, EventArgs args)
	{
		try {
			if (FilesManager_.HasFocus) {
				FilesManager_.Cut (Clipboard.Get(CLIPBOARD));
			} else {
	    			Studio.ShowTodoError ("cut_cb");
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_paste_cb (object o, EventArgs args)
	{
		try {
			if (FilesManager_.HasFocus) {
				FilesManager_.Paste (Clipboard.Get(CLIPBOARD));
			} else {
	    			Studio.ShowTodoError ("paste_cb");
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_clear_cb (object o, EventArgs args)
	{
		try {
			if (FilesManager_.HasFocus) {
				FilesManager_.Clear ();
			} else {
	    			Studio.ShowTodoError ("clear_cb");
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_undo_cb (object o, EventArgs args)
	{
		try {
			if (FilesManager_.HasFocus) {
				FilesManager_.Undo ();
			} else {
	    			Studio.ShowTodoError ("undo_cb");
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_redo_cb (object o, EventArgs args)
	{
		try {
			if (FilesManager_.HasFocus) {
				FilesManager_.Redo ();
			} else {
	    			Studio.ShowTodoError ("Redo_cb");
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_indent_cb (object o, EventArgs args)
	{
		try {
			Console.WriteLine ("indent_cb");	
	    		// Studio.ShowTodoError ("indent_cb");	    		
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_find_cb (object o, EventArgs args)
	{
		try {
			if (!FilesManager_.HasFocus) {
	    			Studio.ShowTodoError ("find_cb");
	    			return;
			}
			FilesManager_.Current.PrepareFindOrReplace (false);
			FindReplaceDialog dialog = new FindReplaceDialog (MainWindow);
			dialog.Selection = FilesManager_.Current.Selection;
			if (dialog.Run () == ResponseType.Ok) {
				FilesManager_.Current.FindOrReplace (false);
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_find_next_cb (object o, EventArgs args)
	{
		try {
			if (FilesManager_.HasFocus) {
				FilesManager_.Current.FindOrReplace (false);
			} else {
	    			Studio.ShowTodoError ("find_cb");
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_replace_cb (object o, EventArgs args)
	{
		try {
			if (!FilesManager_.HasFocus) {
	    			Studio.ShowTodoError ("replace_cb");
	    			return;
			}
			FilesManager_.Current.PrepareFindOrReplace (true);
			FindReplaceDialog dialog = new FindReplaceDialog (MainWindow);
			dialog.Selection = FilesManager_.Current.Selection;
			dialog.Replace = true;
			if (dialog.Run () == ResponseType.Ok) {
				while (FilesManager_.Current.FindOrReplace (true) && Settings.FindRepaceAll) {
					// do nothing
				}
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_find_files_cb (object o, EventArgs args)
	{
		try {
			// todo: save all but new files w/o filenames
			FindReplaceDialog dialog = new FindReplaceDialog (MainWindow);
			dialog.Selection = FilesManager_.Current.Selection;
			dialog.Files = true;
			if (dialog.Run () == ResponseType.Ok) {
				FilesManager_.SaveAll (false);
				OutputManager_.Show (OutputManager_.Find);
				OutputManager_.Find.Run (FindReplaceDialog.GrepCommand, Studio.TopFolder);
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_preferences_cb (object o, EventArgs args)
	{
		try {
			PreferencesDialog dialog = new PreferencesDialog (MainWindow);
			dialog.Run();
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	// project menu
	public void on_project_new_cb (object o, EventArgs args)
	{
		try {
			NewProjectDialog dialog = new NewProjectDialog (MainWindow_);
			if (dialog.Run () == ResponseType.Ok 
				&& EnsureProjectIsSaved ()
				&& FilesManager_.CloseAllFiles ()) {

		    		AdoptProject (dialog.Project, true);
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}

	public void on_project_open_cb (object o, EventArgs args)
	{
		try {
			FileSelectionDialog dialog = new FileSelectionDialog (MainWindow_, "Open project", 
								FileAccess.Read, Settings.LastOpenedProject);
			dialog.SelectMultiple = false;
			if (dialog.Run () == ResponseType.Ok) {
				Studio.OpenProject (dialog.Filename);
			}
    		} catch (System.Xml.XmlException exception) {
			Studio.ShowError (String.Format ("The selected file does not contain a valid project file."));
		} catch (System.IO.FileNotFoundException exception) {
			Studio.ShowError (exception.Message);
		} catch (System.UnauthorizedAccessException exception) {
			Studio.ShowError (exception.Message);
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}
	
	public void on_project_save_cb (object o, EventArgs args)
	{
		try {
			Project_.Save ();
		} catch (System.IO.FileNotFoundException exception) {
			Studio.ShowError (exception.Message);
		} catch (System.UnauthorizedAccessException exception) {
			Studio.ShowError (exception.Message);
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	public void on_project_reload_cb (object o, EventArgs args)
	{
		try {
			ProjectManager_.ReloadProject ();
		} catch (System.IO.FileNotFoundException exception) {
			Studio.ShowError (exception.Message);
		} catch (System.UnauthorizedAccessException exception) {
			Studio.ShowError (exception.Message);
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	public void on_project_edit_cb (object o, EventArgs args)
	{
		try {
			EditProjectDialog dialog = new EditProjectDialog (MainWindow_, Project_);
			if (dialog.Run () == ResponseType.Ok) {
				AdoptProject (dialog.Project, false);
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_project_new_folder_cb (object sender, EventArgs e)
	{
		try {
			Studio.ShowTodoError ("on_project_new_folder_cb");
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_project_add_folder_cb (object sender, EventArgs e)
	{
		try {
			Studio.ShowTodoError ("on_project_add_folder_cb");
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_project_remove_folder_cb (object sender, EventArgs e)
	{
		try {
			ProjectFile folder = ProjectManager_.FilesView.SelectedFile;
			if (folder != null) {
				string [] excluded = Project.ExcludedFiles;
				Project.ExcludedFiles = Project.AddString (excluded, Path.Combine (folder.FullPath, "*"));
				ProjectManager_.ReloadProject ();
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_project_open_file_cb (object sender, EventArgs e)
	{
		try {
			Studio.ShowTodoError ("on_project_open_file_cb");
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_project_add_file_cb (object sender, EventArgs e)
	{
		try {
			Studio.ShowTodoError ("on_project_add_file_cb");
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_project_remove_file_cb (object sender, EventArgs e)
	{
		try {
			ProjectFile file = ProjectManager_.FilesView.SelectedFile;
			if (file != null) {
				string [] excluded = Project.ExcludedFiles;
				Project.ExcludedFiles = Project.AddString (excluded, file.FullPath);
				ProjectManager_.ReloadProject ();
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}
	

	public void on_project_close_cb (object o, EventArgs args)
	{
		try {
			if  (FilesManager_.CloseAllFiles ()) {
				AdoptProject (null, true);
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	public void on_project_build_cb (object o, EventArgs args)
	{
		try {
			FilesManager_.SaveAll (false);
			OutputManager_.Show (OutputManager_.Build);
			OutputManager_.Build.Run (Project_.BuildCommand, Project_.TopBuildFolder);
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	public void on_project_build_clean_cb (object o, EventArgs args)
	{
		try {
			FilesManager_.SaveAll (false);
			OutputManager_.Show (OutputManager_.Build);
			OutputManager_.Build.Run (Project_.BuildCleanCommand, Project_.TopBuildFolder);
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_project_rebuild_cb (object o, EventArgs args)
	{
		try {
			FilesManager_.SaveAll (false);
			OutputManager_.Show (OutputManager_.Build);
			OutputManager_.Build.Run (Project_.RebuildCommand, Project_.TopBuildFolder);
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_project_execute_cb (object o, EventArgs args)
	{
		try {
			// todo: build before execute?
			FilesManager_.SaveAll (false);
			OutputManager_.Show (OutputManager_.Execute);
			OutputManager_.Execute.Run (Project_.ExecuteCommand, Project_.TopProjectFolder);
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}
		
	void on_view_toolbar_cb (object o, EventArgs args)
	{
		try {
			Settings.ShowFileButtons 	= MainMenu_.IsItemActive ("view_toolbar_file");
			Settings.ShowEditButtons 	= MainMenu_.IsItemActive ("view_toolbar_edit");
			Settings.ShowBuildButtons 	= MainMenu_.IsItemActive ("view_toolbar_build");
			Settings.ShowFindButtons 	= MainMenu_.IsItemActive ("view_toolbar_find");
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_next_window_cb (object o, EventArgs args)
	{
		try {
		    	FilesManager_.Next ();		
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}
		
	void on_prev_window_cb (object o, EventArgs args)
	{
		try {
		    	FilesManager_.Prev ();		
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}
		
		
	void on_about_cb (object o, EventArgs args)
	{
		try {
			String[] authors = new string[] {
				"Aleksey Sanin (aleksey@aleksey.com)"
			};
			string[] documentors = new string[] {};
			Pixbuf logo = new Pixbuf (Defines.GetPixmapFile ("csharp-studio-logo.png"));

			About about = new About (Defines.PackageTitle, Defines.Version,
		                         "Copyright (C) 2003 Aleksey Sanin",
					 Defines.PackageTitle,
					 authors, documentors, "", 
					 logo);
			about.Show ();
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}
	
	// project files tree view cb
	void on_project_files_treeview_row_activated_cb (object o, RowActivatedArgs args)
	{
		try {
			TreeView tv = (TreeView) o;
			TreePath path = args.Path;
			if (tv.RowExpand (path))
				tv.CollapseRow (path);
    			else
				tv.ExpandRow (path, true);
	
			ProjectFile file = ProjectManager_.GetItem (args.Path);
			if (file != null && !file.IsFolder) {
				FilesManager_.OpenFile (file.FullPath);
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}
	
	void on_project_files_button_press_cb (object o, ButtonPressEventArgs args)
	{		
		try {
			if (args.Event.type == EventType.ButtonPress && args.Event.button == 3) {
				ProjectManager_.FilesView.ShowPopupMenu (args.Event.x, args.Event.y);
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}

	void on_project_files_popup_menu_cb (object o, PopupMenuArgs args)
	{
		try {
			ProjectManager_.FilesView.ShowPopupMenu ();
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
		Studio.UpdateUI ();
	}
}

}
