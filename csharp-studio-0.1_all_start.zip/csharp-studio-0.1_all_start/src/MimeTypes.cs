///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using System;
using System.Collections;

namespace CSharpStudio
{
	class MimeTypes
	{
		static Hashtable mimeTypes;

		static MimeTypes ()
		{
			mimeTypes = new Hashtable (CaseInsensitiveHashCodeProvider.Default,
						   CaseInsensitiveComparer.Default);

                	mimeTypes.Add ("asm", "text/x-asm");
                	mimeTypes.Add ("c", "text/x-c");
                	mimeTypes.Add ("c++", "text/x-c++");
                	mimeTypes.Add ("cc", "text/x-c++");
			mimeTypes.Add ("cpp", "text/x-cpp");
                	mimeTypes.Add ("cxx", "text/x-cxx");
                	mimeTypes.Add ("cs", "text/x-csharp");
                	mimeTypes.Add ("desktop", "application/x-desktop");
			mimeTypes.Add ("diff", "text/x-diff");
                	mimeTypes.Add ("glade", "text/xml");
                	mimeTypes.Add ("h", "text/x-c-header");
                	mimeTypes.Add ("htm", "text/html");
                	mimeTypes.Add ("html", "text/html");
                	mimeTypes.Add ("htmls", "text/html");
                	mimeTypes.Add ("htt", "text/webviewhtml");
                	mimeTypes.Add ("htx ", "text/html");
                	mimeTypes.Add ("idl ", "text/x-idl");
                	mimeTypes.Add ("jav", "text/x-java");
                	mimeTypes.Add ("java", "text/x-java");
                	mimeTypes.Add ("js", "text/x-java");
                	mimeTypes.Add ("latex ", "application/x-tex");
                	mimeTypes.Add ("ltx", "application/x-tex");
                	mimeTypes.Add ("patch", "text/x-patch");
                	mimeTypes.Add ("pl", "text/x-perl");
                	mimeTypes.Add ("perl", "text/x-perl");
                	mimeTypes.Add ("po", "text/x-po");
                	mimeTypes.Add ("pox", "text/x-pox");
			mimeTypes.Add ("py", "text/x-python");
                    	mimeTypes.Add ("text", "text/plain");
                	mimeTypes.Add ("txt", "text/plain");
                	mimeTypes.Add ("xml", "text/xml");
		}

		public static string GetMimeType (string fileName)
		{
			string result = null;
			int dot = fileName.LastIndexOf ('.');

			if (dot != -1 && fileName.Length > dot + 1)
				result = mimeTypes [fileName.Substring (dot + 1)] as string;

			if (result == null)
				result = "application/octet-stream";

			return result;
		}
	}
}

