///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.IO;

namespace CSharpStudio {

public class FindReplaceDialog : ModalDialog {
	bool Replace_ = false;
	bool Files_ = false;
	string Selection_ = null;

	// find	
	Gtk.Label FindLabel_;
	Gnome.Entry FindEntry_;
	Gtk.CheckButton CaseCheckButton_;
	Gtk.CheckButton WholeWordsCheckButton_;
	Gtk.CheckButton BackwardsCheckButton_;
	Gtk.CheckButton RegexpCheckButton_;

	// replace
	Gtk.Label RepaceLabel_;
	Gnome.Entry ReplaceEntry_;
	Gtk.CheckButton ReplacePromptCheckButton_;	
	Gtk.CheckButton ReplaceAllCheckButton_;
	
	// files
	Gtk.Label FilesFolderLabel_;
	Gnome.FileEntry FilesFolderEntry_;	
	Gtk.Label FilesExtLabel_;
	Gnome.Entry FilesExtEntry_;	

        public FindReplaceDialog (Gtk.Window parent) : base (parent, "find_replace_dialog")
        {
		FindEntry_ 			= (Gnome.Entry)GladeXml_ ["find_replace_dialog_find_entry"];
		FindLabel_			= (Gtk.Label)GladeXml_ ["find_replace_dialog_find_label"];
		CaseCheckButton_		= (Gtk.CheckButton)GladeXml_ ["find_replace_dialog_case_checkbutton"];
		WholeWordsCheckButton_		= (Gtk.CheckButton)GladeXml_ ["find_replace_dialog_words_checkbutton"];
		BackwardsCheckButton_ 		= (Gtk.CheckButton)GladeXml_ ["find_replace_dialog_backwards_checkbutton"];
		RegexpCheckButton_ 		= (Gtk.CheckButton)GladeXml_ ["find_replace_dialog_regexp_checkbutton"];

		RepaceLabel_ 			= (Gtk.Label)GladeXml_ ["find_replace_dialog_replace_label"];
		ReplaceEntry_ 			= (Gnome.Entry)GladeXml_ ["find_replace_dialog_replace_entry"];
		ReplacePromptCheckButton_	= (Gtk.CheckButton)GladeXml_ ["find_replace_dialog_replace_prompt_checkbutton"];
		ReplaceAllCheckButton_ 		= (Gtk.CheckButton)GladeXml_ ["find_replace_dialog_replace_all_checkbutton"];

		FilesFolderLabel_ 		= (Gtk.Label)GladeXml_ ["find_replace_dialog_folder_label"];
		FilesFolderEntry_ 		= (Gnome.FileEntry)GladeXml_ ["find_replace_dialog_folder_fileentry"];
		FilesExtLabel_ 			= (Gtk.Label)GladeXml_ ["find_replace_dialog_ext_label"];
		FilesExtEntry_ 			= (Gnome.Entry)GladeXml_ ["find_replace_dialog_ext_entry"];
	}
	
	protected override bool TransferDataToWindow ()
	{
		Dialog_.Title = (Replace_) ? "Replace" : "Find";

		FindEntry_.GtkEntry.Text 	= (Selection_ != null) ? Selection_ : Settings.FindReplaceFindString;
		CaseCheckButton_.Active 	= Settings.FindRepaceWithCase;
		WholeWordsCheckButton_.Active 	= Settings.FindRepaceWholeWords;
		BackwardsCheckButton_.Active 	= Settings.FindRepaceBackwards;
		RegexpCheckButton_.Active 	= Settings.FindRepaceRegexp;

		if (Replace_) {
			RepaceLabel_.Visible 			= true;
			ReplaceEntry_.Visible			= true;
			ReplaceEntry_.GtkEntry.Text 		= Settings.FindReplaceReplaceString;
			ReplacePromptCheckButton_.Visible	= true;
			ReplacePromptCheckButton_.Active 	= Settings.FindRepacePrompt;
			
			ReplaceAllCheckButton_.Visible 		= true;
			ReplaceAllCheckButton_.Active 		= Settings.FindRepaceAll;
		}

		if (Files_) {
			BackwardsCheckButton_.Sensitive		= false;
			RegexpCheckButton_.Active		= true; // todo: no regexp expressions in search!
			
			FilesFolderLabel_.Visible		= true;
			FilesFolderEntry_.Visible		= true;
			FilesFolderEntry_.GtkEntry.Text		= Settings.FindReplaceFolder;
			
			FilesExtLabel_.Visible			= true;
			FilesExtEntry_.Visible			= true;
			FilesExtEntry_.GtkEntry.Text		= Settings.FindReplaceExtension;
		}
		
		return true;
	}
	
	protected override bool TransferDataFromWindow ()
	{
		Settings.FindReplaceFindString 			= FindEntry_.GtkEntry.Text;
		FindEntry_.PrependHistory (true, FindEntry_.GtkEntry.Text);

		Settings.FindRepaceWithCase 			= CaseCheckButton_.Active;
		Settings.FindRepaceWholeWords 			= WholeWordsCheckButton_.Active;
		Settings.FindRepaceBackwards 			= BackwardsCheckButton_.Active;
		Settings.FindRepaceRegexp 			= RegexpCheckButton_.Active;

		if (Replace_) {
			Settings.FindReplaceReplaceString 	= ReplaceEntry_.GtkEntry.Text;
			ReplaceEntry_.PrependHistory (true, ReplaceEntry_.GtkEntry.Text);
			
			Settings.FindRepacePrompt 		= ReplacePromptCheckButton_.Active;
			Settings.FindRepaceAll 			= ReplaceAllCheckButton_.Active;
		}
		
		if (Files_) {
			Settings.FindReplaceFolder		= FilesFolderEntry_.GtkEntry.Text;
			FilesFolderEntry_.GnomeEntry.PrependHistory (true, FilesFolderEntry_.GtkEntry.Text);
			
			Settings.FindReplaceExtension		= FilesExtEntry_.GtkEntry.Text;
			FilesExtEntry_.PrependHistory (true, FilesExtEntry_.GtkEntry.Text);
		}
		return true;
	}

	static public string GrepCommand 
	{
		get {
			string command = "grep -n -R ";

			if (!Settings.FindRepaceWithCase) {
				command += "-i ";
			}
		
			if (Settings.FindRepaceWholeWords) {
				command += "-w ";
			}

			char[] delim = new char[] {';', ',', ' '};
			string[] ext = Settings.FindReplaceExtension.Split (delim);
			if (ext != null) {
				for (int i = 0; i < ext.Length; i++) {
					command += String.Format ("--include='{0}' ", ext [i]);
				}
			}
			
			// todo: safe quote ' --> \' ? 
			command += String.Format ("'{0}' ", Settings.FindReplaceFindString);
			if (Path.IsPathRooted (Settings.FindReplaceFolder)) {
				command += Settings.FindReplaceFolder;
			} else {
				command += Path.Combine (Studio.TopFolder, Settings.FindReplaceFolder);
			}
			
			return command;
		}	
	}
	
	public string Selection {
		set {
			Selection_ = value;
		}
	}
	
	public bool Replace {
		set {
			Replace_ = value;
		}
	}

	public bool Files {
		set {
			Files_ = value;
		}
	}

}

}
