///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.IO;

namespace CSharpStudio {

public class ModalDialog {
	string Name_;
	string HelpTopic_ = null;
	protected ResponseType Response_ = ResponseType.Cancel;
	
	protected Glade.XML GladeXml_;
	protected Dialog Dialog_;
		
        public ModalDialog (Gtk.Window parent, string name)
        {
		Name_ = HelpTopic_ = name;
		GladeXml_ = new Glade.XML (Defines.GladeFile, Name_, null);
		GladeXml_.Autoconnect (this);

		Dialog_ = (Dialog) GladeXml_ [Name_];
		if (parent != null) {
			// Dialog_.Reparent (parent);
			// Dialog_.WindowPosition = WindowPosition.CenterOnParent;
		}
	}
	
	public string HelpTopic {
		get {
			return HelpTopic_;
		}
		
		set {
			HelpTopic_ = value;
		}
	}
	
	public ResponseType Run ()
	{
		if (!TransferDataToWindow ()) {
			Dialog_.Hide ();
			return ResponseType.Cancel;
		}
		
		Dialog_.Show ();
		Application.Run ();
		Dialog_.Hide ();

		return Response_;
	}
	
	protected void ShowError (string message)
	{
		MessageDialog dialog = new MessageDialog (Dialog_, DialogFlags.DestroyWithParent, 
						    MessageType.Error, ButtonsType.Ok, message);
		dialog.Run ();
		dialog.Destroy ();
		
	}

	protected virtual bool TransferDataToWindow ()
	{
		return true;
	}
	
	protected virtual bool TransferDataFromWindow ()
	{
		return true;
	}

	public void on_response_cb (object o, ResponseArgs args)
	{
		try {
			Response_ = (ResponseType)args.ResponseId;
	    		switch (Response_) {
		    	case ResponseType.Ok:		
				if(TransferDataFromWindow ()) {
					Application.Quit ();
				}
				break;
		    	case ResponseType.Yes:		
				if(TransferDataFromWindow ()) {
					Application.Quit ();
				}
				break;
		    	case ResponseType.Apply:		
				if(TransferDataFromWindow ()) {
					Application.Quit ();
				}
				break;
			case ResponseType.Help:
				Help.ShowTopic (HelpTopic_);
				break;
			default:
				Application.Quit ();
				break;
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
    	}

}

}
