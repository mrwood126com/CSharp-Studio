///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using System;
using Gtk;
using GConf;

namespace CSharpStudio
{	
	public class Settings
	{
		static GConf.Client Client_ = new GConf.Client ();
		static int MaxRecentItems = 16;
		static string Root_ = "/apps/csharp-studio";

		public static string RecentFilesListName = "recent-files";
 		public static string RecentProjectsListName = "recent-projects";
 		
		static Settings ()
		{
		}
		
		public static void SaveWindowSize (Window window, string name)
		{
			int width, height;	
			
			window.GetSize (out width, out height);
			Client_.Set (String.Format ("{0}/windows/{1}/width", Root_, name), width);
			Client_.Set (String.Format ("{0}/windows/{1}/height", Root_, name), height);
		}
	
		public static void RestoreWindowSize (Window window, string name)
		{
			try {
				int width = (int) Client_.Get (String.Format ("{0}/windows/{1}/width", Root_, name));
				int height = (int) Client_.Get (String.Format ("{0}/windows/{1}/height", Root_, name));
				if (width > 0 && height > 0) 
					window.Resize (width, height);
			} catch (NoSuchKeyException ex) {
				// not a problem for us
			}
		}
		
		public static void SavePanedPosition (Paned paned, string name)
		{
			Client_.Set (String.Format ("{0}/windows/{1}/paned-position", Root_, name), paned.Position);
		}

		public static void RestorePanedPosition (Paned paned, string name)
		{
			try {
    				paned.Position = (int)Client_.Get (String.Format ("{0}/windows/{1}/paned-position", Root_, name));
			} catch (NoSuchKeyException ex) {
				// not a problem for us
			}
		}
		
		public static string[] GetRecentItemsList (string name)
		{
			string [] res = new string [MaxRecentItems];
			try {
				for (int i = 0; i < MaxRecentItems; i++) {
					res [i] = (string)Client_.Get (String.Format ("{0}/{1}/item{2}", Root_, name, i));
				}
			} catch (NoSuchKeyException ex) {
				// not a problem for us
			}
			return res;
		}
		
		static void SetRecentItemsList (string name, string[] items)
		{
			int i;
			for (i = 0; i < items.Length && i < MaxRecentItems; i++) {
				if (items [i] == null || items [i] == String.Empty) {
					break;
				}
				Client_.Set (String.Format ("{0}/{1}/item{2}", Root_, name, i), items [i]);
			}
			for (;i < MaxRecentItems; i++) {
				Client_.Set (String.Format ("{0}/{1}/item{2}", Root_, name, i), String.Empty);
			}
		}
		
		static void AddToRecentItemsList (string name, string item)
		{
			string [] curList = GetRecentItemsList (name);
			string [] newList = new string [MaxRecentItems];
			int i, j;
			
			newList [0] = item;
			for  (i = 0, j = 1; i < MaxRecentItems && j < MaxRecentItems; i++) {
				if (curList [i] == null || curList [i] == String.Empty) {
					break;
				} 
				if (curList [i] != item) {
					newList [j++] = curList [i]; 
				}
			}
			SetRecentItemsList (name, newList);
		}

		public static void AddRecentItemsListChangedHandler (string name, GConf.NotifyEventHandler handler)
		{
			// todo: if I set notification handler for the top folder
			// then I get it too many times
			Client_.AddNotify (String.Format ("{0}/{1}/item0", Root_, name), handler);
		}
			
		public static void RemoveRecentItemsListChangedHandler (string name, GConf.NotifyEventHandler handler)
		{
			Client_.RemoveNotify (String.Format ("{0}/{1}/item0", Root_, name), handler);
		}
		
		public static string LastOpenedProject {
			get {
				string [] recentProjects = GetRecentItemsList (RecentProjectsListName);
				if (recentProjects.Length == 0 || recentProjects [0] == null) {
					return String.Empty;
				}
				return recentProjects [0];
			}
			
			set {
				AddToRecentItemsList (RecentProjectsListName, value);
			}
		}
		
		public static string LastOpenedFile {
			get {
				string [] recentFiles = GetRecentItemsList (RecentFilesListName);
				if (recentFiles.Length == 0 || recentFiles [0] == null) {
					return String.Empty;
				}
				return recentFiles [0];
			}
			
			set {
				AddToRecentItemsList (RecentFilesListName, value);
			}
		}

		public static string FindReplaceFindString {
			get {
				string res = "";
				try {
    					res = (string)Client_.Get (String.Format ("{0}/find-replace/find-string", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/find-replace/find-string", Root_), value);
			}	
		}

		public static string FindReplaceReplaceString {
			get {
				string res = "";
				try {
    					res = (string)Client_.Get (String.Format ("{0}/find-replace/replace-string", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/find-replace/replace-string", Root_), value);
			}	
		}

		public static string FindReplaceFolder {
			get {
				string res = "";
				try {
    					res = (string)Client_.Get (String.Format ("{0}/find-replace/folder", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/find-replace/folder", Root_), value);
			}	
		}

		public static string FindReplaceExtension {
			get {
				string res = "";
				try {
    					res = (string)Client_.Get (String.Format ("{0}/find-replace/extension", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/find-replace/extension", Root_), value);
			}	
		}

		public static bool FindRepaceWithCase {
			get {
				bool res = false;
				try {
    					res = (bool)Client_.Get (String.Format ("{0}/find-replace/case", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/find-replace/case", Root_), value);
			}
		}

		public static bool FindRepaceWholeWords {
			get {
				bool res = false;
				try {
    					res = (bool)Client_.Get (String.Format ("{0}/find-replace/whole-words", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/find-replace/whole-words", Root_), value);
			}
		}

		public static bool FindRepaceRegexp {
			get {
				bool res = false;
				try {
    					res = (bool)Client_.Get (String.Format ("{0}/find-replace/regexp", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/find-replace/regexp", Root_), value);
			}
		}

		public static bool FindRepaceBackwards {
			get {
				bool res = false;
				try {
    					res = (bool)Client_.Get (String.Format ("{0}/find-replace/backwards", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/find-replace/backwards", Root_), value);
			}
		}

		public static bool FindRepacePrompt {
			get {
				bool res = false;
				try {
    					res = (bool)Client_.Get (String.Format ("{0}/find-replace/replace-prompt", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/find-replace/replace-prompt", Root_), value);
			}
		}

		public static bool FindRepaceAll {
			get {
				bool res = false;
				try {
    					res = (bool)Client_.Get (String.Format ("{0}/find-replace/replace-all", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/find-replace/replace-all", Root_), value);
			}
		}

		
		public static int EditProjectDialogTab {
			get {
				int res = 0;
				try {
    					res = (int)Client_.Get (String.Format ("{0}/dialogs/edit-project/opened-tab", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}

			set {
				Client_.Set (String.Format ("{0}/dialogs/edit-project/opened-tab", Root_), value);
			}
		}

		public static int PreferencesDialogTab {
			get {
				int res = 0;
				try {
    					res = (int)Client_.Get (String.Format ("{0}/dialogs/preferences/opened-tab", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}

			set {
				Client_.Set (String.Format ("{0}/dialogs/preferences/opened-tab", Root_), value);
			}
		}

		public static bool AutoSaveProject {
			get {
				bool res = true;
				try {
    					res = (bool)Client_.Get (String.Format ("{0}/auto-save/project", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/auto-save/project", Root_), value);
			}
		}

		public static bool AutoSaveFiles {
			get {
				bool res = false;
				try {
    					res = (bool)Client_.Get (String.Format ("{0}/auto-save/files", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/auto-save/files", Root_), value);
			}
		}

		public static bool ShowLineNumbers {
			get {
				bool res = false;
				try {
    					res = (bool)Client_.Get (String.Format ("{0}/editor/show-line-numbers", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/editor/show-line-numbers", Root_), value);
			}
		}

		public static bool EnableAutoIndent {
			get {
				bool res = false;
				try {
    					res = (bool)Client_.Get (String.Format ("{0}/editor/enable-auto-indent", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/editor/enable-auto-indent", Root_), value);
			}
		}

		public static bool EnableSmartHomeEnd {
			get {
				bool res = false;
				try {
    					res = (bool)Client_.Get (String.Format ("{0}/editor/enable-smart-home-end", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/editor/enable-smart-home-end", Root_), value);
			}
		}

		public static string EditorFontName {
			get {
				string res = "";
				try {
    					res = (string)Client_.Get (String.Format ("{0}/editor/font-name", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/editor/font-name", Root_), value);
			}
		}

		public static event GConf.NotifyEventHandler EditorSettingsChanged
		{
			add {
				Client_.AddNotify (String.Format ("{0}/editor", Root_), value);
			}
			
			remove{
				Client_.RemoveNotify (String.Format ("{0}/editor", Root_), value);
			}
		}

		public static bool ShowFileButtons {
			get {
				bool res = true;
				try {
    					res = (bool)Client_.Get (String.Format ("{0}/toolbar/show-file-buttons", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/toolbar/show-file-buttons", Root_), value);
			}
		}

		public static bool ShowEditButtons {
			get {
				bool res = true;
				try {
    					res = (bool)Client_.Get (String.Format ("{0}/toolbar/show-edit-buttons", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/toolbar/show-edit-buttons", Root_), value);
			}
		}
		
		public static bool ShowBuildButtons {
			get {
				bool res = true;
				try {
    					res = (bool)Client_.Get (String.Format ("{0}/toolbar/show-build-buttons", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/toolbar/show-build-buttons", Root_), value);
			}
		}

		public static bool ShowFindButtons {
			get {
				bool res = true;
				try {
    					res = (bool)Client_.Get (String.Format ("{0}/toolbar/show-find-buttons", Root_));
				} catch (NoSuchKeyException ex) {
					// not a problem for us
				}
				return res;
			}
			
			set {
				Client_.Set (String.Format ("{0}/toolbar/show-find-buttons", Root_), value);
			}
		}

		public static event GConf.NotifyEventHandler ToolbarSettingsChanged
		{
			add {
				Client_.AddNotify (String.Format ("{0}/toolbar", Root_), value);
			}
			
			remove{
				Client_.RemoveNotify (String.Format ("{0}/toolbar", Root_), value);
			}
		}

	}
}
