///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using Gdk;
using Glade;
using Gnome;
using Gtk;
using GtkSharp;
using Pango;
using System;
using System.IO;

namespace CSharpStudio {

public class FileView {
	string Path_ = null;
	Label Title_;
	
        public FileView () 
        {
		Title_ = new Label (Filename);
		Title_.CanFocus = false;
	}

	virtual public void UpdateUI ()
	{
		if (Modified) {
			Title_.Markup = String.Format ("<b>{0}*</b>", Filename);
		} else {
			Title_.Text = Filename;
		}
	}

	virtual public void ReloadProject ()
	{
	}
	
	virtual public void OpenFile (string path)
	{
	}
	
	virtual public void SaveFile (string path)
	{
	}

	virtual public void GotoLine (int line)
	{
	}

	virtual public void Copy (Clipboard clipboard) 
	{
	}

	virtual public void Cut (Clipboard clipboard) 
	{
	}

	virtual public void Paste (Clipboard clipboard) 
	{
	}

	virtual public void Clear ()
	{
	}
	
	virtual public void Undo ()
	{
	}

	virtual public void Redo ()
	{
	}

	virtual public void PrepareFindOrReplace (bool replace)
	{
	}
	
	virtual public bool FindOrReplace (bool replace)
	{
		return false;
	}

	virtual public string Selection
	{
		get {
			return null;
		}
	}
		
	virtual public Widget TopWidget 
	{
		get {
			return null;
		}
	}
		
	virtual public Widget Title
	{
		get {
			return Title_;
		}
	}
	
	virtual public string Filename
	{
		get {
			if (Path_ == null || Path_ == String.Empty) {
				return "untitled";
			}
			return System.IO.Path.GetFileName (Path_);
		}
	}
	
	virtual public string Path
	{
		get {
			return Path_;
		}		
		set {
			if (Path_ != value) {
				Path_ = value;
				Title_.Text = Filename;
			}
		}
	}
	
	virtual public bool Modified 
	{
		get {
			return false;
		}
	}

	virtual public bool HasFocus 
	{
		get {
			return false;
		}
	}

}

}
