///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.IO;

namespace CSharpStudio {

public class ExceptionDialog : ModalDialog {
	string Exception_;
	string Message_;
	string StackTrace_;
	
	Gtk.Label MessageLabel_;
	Gtk.TextView StackTraceText_;
	Gtk.ScrolledWindow StackTraceScrolledWindow_;
	Gtk.Button ShowStackTraceButton_;
	Gtk.Button HideStackTraceButton_;
	
        public ExceptionDialog (Gtk.Window parent, string exception, string message, string stack) : base (parent, "exception_dialog")
        {
		Exception_ 			= exception;
		Message_			= message;
		StackTrace_			= stack;
		
		MessageLabel_ 			= (Gtk.Label)GladeXml_ ["exception_dialog_message_label"];
		StackTraceText_ 		= (Gtk.TextView)GladeXml_ ["exception_dialog_stacktrace_textview"];
		StackTraceScrolledWindow_	= (Gtk.ScrolledWindow)GladeXml_ ["exception_dialog_stacktrace_scrolledwindow"];
		ShowStackTraceButton_ 		= (Gtk.Button)GladeXml_ ["exception_dialog_show_stacktrace_button"];
		HideStackTraceButton_		= (Gtk.Button)GladeXml_ ["exception_dialog_hide_stacktrace_button"];

	}
	
	protected override bool TransferDataToWindow ()
	{
		Dialog_.Title 			= String.Format ("Exception {0}", Exception_);
		MessageLabel_.Text 		= Message_;
		StackTraceText_.Buffer.Text	= StackTrace_;
		
		return true;
	}
	
	protected override bool TransferDataFromWindow ()
	{
		return true;
	}
	
	public void on_show_stacktrace_button_clicked_cb (object o, EventArgs args)
	{
		try {
			StackTraceText_.Visible 		= true;
			StackTraceScrolledWindow_.Visible 	= true;
			ShowStackTraceButton_.Visible 		= false;
			HideStackTraceButton_.Visible 		= true;
		} catch (Exception exception) {
			// do nothing: we are already showing exception dialog
			Console.WriteLine ("ExceptionDialog.on_show_stacktrace_button_clicked_cb: exception");
		}
	}
	
	public void on_hide_stacktrace_button_clicked_cb (object o, EventArgs args)
	{
		try {
			StackTraceText_.Visible 		= false;
			StackTraceScrolledWindow_.Visible 	= false;
			ShowStackTraceButton_.Visible 		= true;
			HideStackTraceButton_.Visible 		= false;
		} catch (Exception exception) {
			// do nothing: we are already showing exception dialog
			Console.WriteLine ("ExceptionDialog.on_hide_stacktrace_button_clicked_cb: exception");
		}
	}
}

}
