///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using GConf;
using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.IO;


namespace CSharpStudio {

public class MainAppBar {
	Glade.XML GladeXml_;
	Gnome.AppBar AppBar_;
	
	Gtk.Label RowLabel_;
	Gtk.Label ColumnLabel_;
	Gtk.Label SpaceLabel_;

        public MainAppBar (AppBar appbar)
        {
		AppBar_ 	= appbar;
		GladeXml_ 	= Glade.XML.GetWidgetTree (AppBar_);
		
		SpaceLabel_	= AddLabel ();		
		ColumnLabel_	= AddLabel ();
		RowLabel_	= AddLabel ();
		
		ClearRowAndColumn ();
		SpaceLabel_.Text= "     ";
		AppBar_.ShowAll ();
	}

	public void SetStatus (string msg)
	{
		AppBar_.SetStatus (msg);
	}
	
	public void SetRowAndColumn (int row, int column)
	{
		RowLabel_.Text		= String.Format ("Ln: {0}", row);  
		ColumnLabel_.Text 	= String.Format ("Col: {0}", column);  
	}
	
	public void ClearRowAndColumn ()
	{
		RowLabel_.Text = ColumnLabel_.Text = "      ";
	}
	
	Gtk.Label AddLabel ()
	{
		Gtk.Frame frame	 	= new Gtk.Frame ();
		frame.ShadowType 	= Gtk.ShadowType.In;
		AppBar_.PackEnd (frame, false, true, 0);

		Gtk.Label label	= new Gtk.Label (String.Empty);
		frame.Add (label);
		
		return label;
	}	
	
}

}
