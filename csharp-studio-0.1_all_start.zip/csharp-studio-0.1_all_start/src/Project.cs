///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using Gtk;
using System;
using System.IO;
using System.Xml;

namespace CSharpStudio {

public class Project  {
        private const string NamespaceURI = "http://www.aleksey.com/csharp-studio/20030728";

        private XmlNode ProjectNode_ = null;
	XmlNamespaceManager NamespaceManager_ = null;
	private string Filename_ = null;
	private bool Modified_ = false;
	
        public Project ()
        {
    		XmlDocument doc = new XmlDocument ();

		NamespaceManager_ = new XmlNamespaceManager (doc.NameTable);
    		NamespaceManager_.AddNamespace ("cse", NamespaceURI);	

    	        ProjectNode_ = doc.CreateElement("cse:Project", NamespaceURI);
    		doc.AppendChild(ProjectNode_);	
        }
    
        public Project (string filename)
        {
		XmlDocument doc = new XmlDocument ();
    		doc.Load (filename);
	    
	        NamespaceManager_ = new XmlNamespaceManager (doc.NameTable);
    		NamespaceManager_.AddNamespace ("cse", NamespaceURI);	

		ProjectNode_ = doc.SelectSingleNode("//cse:Project", NamespaceManager_);
    		if (ProjectNode_ == null) {
    			ProjectNode_ = doc.CreateElement("cse:Project", NamespaceURI);
    			doc.AppendChild(ProjectNode_);
	        }
		Filename_ = filename;
        }

	public Project (Project other)
	{
		XmlDocument doc = (XmlDocument)other.ProjectNode_.OwnerDocument.CloneNode (true);
		NamespaceManager_ = new XmlNamespaceManager (doc.NameTable);
    		NamespaceManager_.AddNamespace ("cse", NamespaceURI);	

		ProjectNode_ = doc.SelectSingleNode("//cse:Project", NamespaceManager_);
    		if (ProjectNode_ == null) {
    			ProjectNode_ = doc.CreateElement("cse:Project", NamespaceURI);
    			doc.AppendChild(ProjectNode_);
		}
		Filename_ = other.Filename_;
		Modified = other.Modified;
	}

	public bool Save ()
	{
		if (!Modified) {
			return true;
		}
		
		string path = Filename;
		if (path == null) {
			FileSelectionDialog dialog = new FileSelectionDialog (Studio.MainWindow, "Save project", 
								FileAccess.Write, "");
			// todo: set folder from LastOpenedProject
			if ((ResponseType)dialog.Run () != ResponseType.Ok) {
				return false;
			}	
			path = dialog.Filename;
		}
		StreamWriter stream = new SafeStreamWriter (Filename);
		ProjectNode_.OwnerDocument.Save (stream);
		stream.Close ();
		Modified = false;
		Filename = path;
		return true;
	}

	string GetStringProperty (string section, string name, string defaultValue)
	{
		string res = null;
		XmlNode node = ProjectNode_.SelectSingleNode ( String.Format ("{0}/{1}", section, name), NamespaceManager_);
		if (node != null) {
			res = node.InnerText;
		}
		// Console.WriteLine ("GetStringProperty: {0}/{1} = {2}", section, name, res);
		return (res != null) ? res : defaultValue;
	}
	
	void SetStringProperty (string section, string name, string value)
	{
		// Console.WriteLine ("SetStringProperty: {0}/{1} = {2}", section, name, value);

		XmlNode sectionNode = ProjectNode_.SelectSingleNode (String.Format ("{0}", section), NamespaceManager_);
		if (sectionNode == null) {
    			sectionNode = ProjectNode_.OwnerDocument.CreateElement(section, NamespaceURI);
    			ProjectNode_.AppendChild(sectionNode);					    
		}
		
		XmlNode node = sectionNode.SelectSingleNode (String.Format ("{0}", name), NamespaceManager_);
		if (node == null) {
    			node = ProjectNode_.OwnerDocument.CreateElement(name, NamespaceURI);
    			sectionNode.AppendChild(node);					    
		} else {
			RemoveAllChildren (node);
		}
		
		XmlNode textNode = ProjectNode_.OwnerDocument.CreateTextNode(value);
		node.AppendChild (textNode);
		Modified = true;
	}

	string GetAttributeProperty (string section, string name, string attribute, string defaultValue)
	{
		string res = null;
		XmlElement node = (XmlElement)ProjectNode_.SelectSingleNode (String.Format ("{0}/{1}", section, name), NamespaceManager_);
		if (node != null) {
			res = node.GetAttribute (attribute);
		}
		// Console.WriteLine ("GetAttributeProperty: {0}/{1}@{2} = {3}", section, name, attribute, res);
		return (res != null) ? res : defaultValue;
	}
	
	void SetAttributeProperty (string section, string name, string attribute, string value)
	{
		// Console.WriteLine ("SetAttributeProperty: {0}/{1}@{2} = {3}", section, name, attribute, value);
		XmlNode sectionNode = ProjectNode_.SelectSingleNode (String.Format ("{0}", section), NamespaceManager_);
		if (sectionNode == null) {
    			sectionNode = ProjectNode_.OwnerDocument.CreateElement(section, NamespaceURI);
    			ProjectNode_.AppendChild(sectionNode);					    
		}
		
		XmlElement node = (XmlElement)sectionNode.SelectSingleNode (String.Format ("{0}", name), NamespaceManager_);
		if (node == null) {
    			node = ProjectNode_.OwnerDocument.CreateElement(name, NamespaceURI);
    			sectionNode.AppendChild(node);					    
		}

		node.SetAttribute (attribute, value);
		Modified = true;
	}
	
	string[] GetItemsList (string section, string name)
	{
		string[] res = null;
		XmlNodeList xnl = ProjectNode_.SelectNodes (String.Format ("{0}/{1}/cse:Item", section, name), NamespaceManager_);
		if (xnl != null) {
			res = new string [xnl.Count];
			int i = 0;
			foreach (XmlNode node in xnl) {	
				res[i++] = node.InnerText;
			}
		}
		return res;
	}
	
	void SetItemsList (string section, string name, string[] value)
	{
		// Console.WriteLine ("SetItemsList: {0}/{1} = {2}", section, name, value);
		XmlNode sectionNode = ProjectNode_.SelectSingleNode (String.Format ("{0}", section), NamespaceManager_);
		if (sectionNode == null) {
    			sectionNode = ProjectNode_.OwnerDocument.CreateElement(section, NamespaceURI);
    			ProjectNode_.AppendChild(sectionNode);					    
		}
		
		XmlNode node = sectionNode.SelectSingleNode (String.Format ("{0}", name), NamespaceManager_);
		if (node == null) {
    			node = ProjectNode_.OwnerDocument.CreateElement(name, NamespaceURI);
    			sectionNode.AppendChild(node);					    
		} else {
			RemoveAllChildren (node);
		}
		
		if (value != null) {
		    for (int i = 0; i < value.Length; ++i) {
    			XmlNode itemNode = ProjectNode_.OwnerDocument.CreateElement("cse:Item", NamespaceURI);
    			node.AppendChild(itemNode);					    
	    
			XmlNode textNode = ProjectNode_.OwnerDocument.CreateTextNode(value[i]);
			itemNode.AppendChild (textNode);

			// Console.WriteLine ("SetItemsList: {0}/{1} - {2}= {3}", section, name, i, value [i]);
		    }
		}
		Modified = true;
	}

	bool GetItemStatus (string section, string name, string item, bool defaultValue)
	{
		XmlNodeList xnl = ProjectNode_.SelectNodes (String.Format ("{0}/{1}/cse:Item", section, name), NamespaceManager_);
		if (xnl == null) {
			return defaultValue;
		}
		foreach (XmlNode node in xnl) {
			if (node.InnerText == item) {
				return ToBoolean (((XmlElement)node).GetAttribute ("Status"));
			}
		}
		
		return defaultValue;
	}
	
	void SetItemStatus (string section, string name, string item, bool value)
	{
		// Console.WriteLine ("SetItemsList: {0}/{1} = {2}", section, name, value);
		XmlNode sectionNode = ProjectNode_.SelectSingleNode (String.Format ("{0}", section), NamespaceManager_);
		if (sectionNode == null) {
    			sectionNode = ProjectNode_.OwnerDocument.CreateElement(section, NamespaceURI);
    			ProjectNode_.AppendChild(sectionNode);					    
		}
		
		XmlNode node = sectionNode.SelectSingleNode (String.Format ("{0}", name), NamespaceManager_);
		if (node == null) {
    			node = ProjectNode_.OwnerDocument.CreateElement(name, NamespaceURI);
    			sectionNode.AppendChild(node);					    
		}

		Modified = true;
		foreach (XmlNode itemNode in node.ChildNodes) {
			if (itemNode.NodeType == XmlNodeType.Element && itemNode.Name == "cse:Item" && itemNode.InnerText == item) {
				((XmlElement)itemNode).SetAttribute ("Status", ToString (value));
				return;
			}
		}
		
		XmlNode newItemNode = ProjectNode_.OwnerDocument.CreateElement ("cse:Item", NamespaceURI);
    		node.AppendChild(newItemNode);	
		((XmlElement)newItemNode).SetAttribute ("Status", ToString (value));
				
		XmlNode textNode = ProjectNode_.OwnerDocument.CreateTextNode (item);
		newItemNode.AppendChild (textNode);
	}
	
	static bool ToBoolean (string str)
	{
		return str == "True";
	}
	
	static string ToString (bool value)
	{
		return (value) ? "True" : "False";
	}

	static void RemoveAllChildren (XmlNode node)
	{
		while (node.FirstChild != null) {
			node.RemoveChild (node.FirstChild);
		}
	}

	public bool Modified {
		get {
			return Modified_;
		}
		
		set {
			if (value != Modified_) {
				Modified_ = value;
			}
			if (Modified_ && Studio.Project == this && Settings.AutoSaveProject) {
				// todo: autosave in the idle?
				Save ();
			}
		}
	}

	public string Filename 
	{
		get {
			return Filename_;
		}
		
		set {
			if (value != Filename_) {
				Filename_ = value;
				Modified_ = true;
			}
		}
	}

	public string Name {
		get {
			return GetStringProperty ("cse:General", "cse:Name", "unknown");
	        }
	    
		set {
			if (value != Name) {
				SetStringProperty ("cse:General", "cse:Name", value);
			}
		}
	}

	public string Description {
		get {
			return GetStringProperty ("cse:General", "cse:Description", "");
	        }
	    
		set {
			if (value != Name) {
				SetStringProperty ("cse:General", "cse:Description", value);
			}
		}
	}

	public string TopProjectFolder {
		get {
			return GetStringProperty ("cse:Files", "cse:TopFolder", "");
	        }
	    
		set {
			if (value != TopProjectFolder) {
				SetStringProperty ("cse:Files", "cse:TopFolder", value);
			}
		}
	}
	
	public string[] IncludedFiles {
		get {
			return GetItemsList ("cse:Files", "cse:IncludedFiles");
	        }
	    
		set {
			if (value != IncludedFiles) {
				SetItemsList ("cse:Files", "cse:IncludedFiles", value);
			}
		}
	}

	public string[] ExcludedFiles {
		get {
			return GetItemsList ("cse:Files", "cse:ExcludedFiles");
	        }
	    
		set {
			if (value != ExcludedFiles) {
				SetItemsList ("cse:Files", "cse:ExcludedFiles", value);
			}
		}
	}
	
	static public string [] AddString (string [] list, string item)
	{
		string [] res = new string [list.Length + 1];
		for (int i = 0; i < list.Length; i++)
		{
			res [i] = list [i];
		}
		res [list.Length] = item;
		return res;
	}

	public bool GetProjectFolderExpandedStatus (string path)
	{
		return GetItemStatus ("cse:Files", "ExpandedFolders", path, false);
	}
	
	public void SetProjectFolderExpandedStatus (string path, bool value)
	{
		if (GetProjectFolderExpandedStatus (path) != value) {
			SetItemStatus ("cse:Files", "ExpandedFolders", path, value);
		}
	}	

	public string TopBuildFolder {
		get {
			return GetStringProperty ("cse:Build", "cse:TopFolder", "");
	        }
	    
		set {
			if (value != TopBuildFolder) {
				SetStringProperty ("cse:Build", "cse:TopFolder", value);
			}
		}
	}

	const string DefaultBuildCommand = "make";
	public string BuildCommand {
		get {
			return (CustomBuildEnabled) ? CustomBuildCommand : DefaultBuildCommand;
		}
	}

	public string CustomBuildCommand {
		get {
			return GetStringProperty ("cse:Build", "cse:CustomBuild", DefaultBuildCommand);
	        }
	    
		set {
			if (value != CustomBuildCommand) {
				SetStringProperty ("cse:Build", "cse:CustomBuild", value);
			}
		}
	}

	public bool CustomBuildEnabled {
		get {
			return ToBoolean (GetAttributeProperty ("cse:Build", "cse:CustomBuild", "Enabled", ToString (false)));
	        }
	    
		set {
			if (value != CustomBuildEnabled) {
	    			SetAttributeProperty ("cse:Build", "cse:CustomBuild", "Enabled", ToString (value));
			}
		}
	}

	const string DefaultBuildCleanCommand = "make clean";
	public string BuildCleanCommand {
		get {
			return (CustomBuildCleanEnabled) ? CustomBuildCleanCommand : DefaultBuildCleanCommand;
		}
	}

	public string CustomBuildCleanCommand {
		get {
			return GetStringProperty ("cse:Build", "cse:CustomBuildClean", DefaultBuildCleanCommand);
	        }
	    
		set {
			if (value != CustomBuildCleanCommand) {
				SetStringProperty ("cse:Build", "cse:CustomBuildClean", value);
			}
		}
	}

	public bool CustomBuildCleanEnabled {
		get {
			return ToBoolean (GetAttributeProperty ("cse:Build", "cse:CustomBuildClean", "Enabled", ToString (false)));
	        }
	    
		set {
			if (value != CustomBuildCleanEnabled) {
	    			SetAttributeProperty ("cse:Build", "cse:CustomBuildClean", "Enabled", ToString (value));
			}
		}
	}


	const string DefaultRebuildCommand = "/bin/sh -c \"{0} && {1}\"";
	public string RebuildCommand {
		get {
			return String.Format (DefaultRebuildCommand, BuildCleanCommand, BuildCommand);
		}
	}

	public string ExecuteTarget {
		get {
			return GetStringProperty ("cse:Execute", "cse:Target", "");
	        }
	    
		set {
			if (value != ExecuteTarget) {
			    	SetStringProperty ("cse:Execute", "cse:Target", value);
			}
		}
	}

	const string DefaultExecuteCommand = "mono {0}";
	public string ExecuteCommand {
		get {
			return (CustomExecuteEnabled) ? CustomExecuteCommand : String.Format (DefaultExecuteCommand, ExecuteTarget);
		}
	}

	public string CustomExecuteCommand {
		get {
			return GetStringProperty ("cse:Execute", "cse:CustomExecute", 
				String.Format (DefaultExecuteCommand, ExecuteTarget));
	        }
	    
		set {
			if (value != CustomExecuteCommand) {
				SetStringProperty ("cse:Execute", "cse:CustomExecute", value);
			}
		}
	}

	public bool CustomExecuteEnabled {
		get {
			return ToBoolean (GetAttributeProperty ("cse:Execute", "cse:CustomExecute", "Enabled", ToString (false)));
	        }
	    
		set {
			if (value != CustomExecuteEnabled) {
				SetAttributeProperty ("cse:Execute", "cse:CustomExecute", "Enabled", ToString (value));
			}
		}
	}

	public uint TabsWidth {
		get {
			return Convert.ToUInt32 (GetStringProperty ("cse:Editor", "cse:TabsWidth", "8"));
	        }
	    
		set {
			if (value != TabsWidth) {
				SetStringProperty ("cse:Editor", "cse:TabsWidth", Convert.ToString (value));
			}
		}
	}

	public bool FillTabs {
		get {
			return ToBoolean (GetStringProperty ("cse:Editor", "cse:FillTabs", ToString (false)));
	        }
	    
		set {
			if (value != FillTabs) {
				SetStringProperty ("cse:Editor", "cse:FillTabs", ToString (value));
			}
		}
	}

	public string[] OpenedFiles {
		get {
			return GetItemsList ("cse:Editor", "cse:OpenedFiles");
	        }
	    
		set {
			if (value != OpenedFiles) {
				SetItemsList ("cse:Editor", "cse:OpenedFiles", value);				
			}
		}
	}
	
}

}
