///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using System;
using System.Collections;
using System.IO;
using System.Threading;

// 1) create the list of top folders
// 2) travel thru files tree and check 
//    each folder or file if it is in 
//    included or excluded list
namespace CSharpStudio {
	public class ProjectFile {
		string Name_;
		string FullPath_;
		string Parent_;
		bool IsFolder_;
		
		public ProjectFile (string name, string path, string parent, bool isFolder)
		{
			Name_ 		= name;
			FullPath_ 	= path;
			Parent_		= parent;
			IsFolder_	= isFolder;
		}

		public ProjectFile (string path, string parent, bool isFolder)
		{
			Name_ 		= Path.GetFileName (path);
			FullPath_ 	= path;
			Parent_		= parent;
			IsFolder_	= isFolder;
		}
		
		public string Name 
		{
			get {
				return Name_;
			}
		}	

		public string FullPath 
		{
			get {
				return FullPath_;
			}
		}	

		public string Parent
		{
			get {
				return Parent_;
			}
		}	

		public bool IsFolder
		{
			get {
				return IsFolder_;
			}
		}	

	}
	
	public class ProjectFilesList {
		string Status_ = String.Empty;
		bool IsFinished_ = false;
		bool Errors_ = false;
		
		string RootFolder_;
		ArrayList IncludedFilesPatterns_;
		ArrayList ExcludedFilesPatterns_;

		SortedList TopFolders_;
		SortedList Folders_;
		SortedList Files_;
		
		Thread Thread_;
		bool Canceled_;
		
		public ProjectFilesList (string root, string[] included, string[] excluded)
		{
			RootFolder_ 		= root;
			IncludedFilesPatterns_	= ParsePatternsList (root, included);
			if (IncludedFilesPatterns_.Count == 0) {	
				IncludedFilesPatterns_.Add (new ProjectFilePattern (root, "*"));
			}
			ExcludedFilesPatterns_	= ParsePatternsList (root, excluded);
			TopFolders_		= new SortedList ();
			Folders_		= new SortedList ();
			Files_			= new SortedList ();
		
			Thread_ 		= new Thread(new ThreadStart(ThreadFunc));
			Canceled_		= false;
		}
		
		public void Start ()
		{
			// Console.WriteLine ("ProjectFilesList.Start");
			CreateTopFoldersList ();
			Thread_.Start ();
		}
		
		public void Cancel ()
		{
			Canceled_ = true;
		}

		public void ThreadFunc ()
		{
			// Console.WriteLine ("ThreadFunc: found {0} top folder(s)", TopFolders_.Count);

			Status = String.Empty;
			for (int i = 0; !Canceled_ && i < TopFolders_.Count; i++) {
				AppendFolder ( (ProjectFile)TopFolders_.GetByIndex (i));
			}
			
			Status 		= String.Empty;
			IsFinished 	= true;
			// Console.WriteLine ("ThreadFunc: found {0} file(s) in {1} folder(s)", FilesCount, FoldersCount);
		}
	
		ArrayList ParsePatternsList (string root, string[] patterns)
		{
			ArrayList list = new ArrayList ();
			if (patterns != null) {
				for (int i = 0; !Canceled_ && i < patterns.Length; i++) {
					string str = patterns [i].Trim ();
					if (str == String.Empty) {
						continue;
					}
					list.Add (new ProjectFilePattern (root, str));
				}
			}
			return (list);
		}
		
		void CreateTopFoldersList ()
		{
			Status = "Creating top folders list";
			for (int i = 0; !Canceled_ && i < IncludedFilesPatterns_.Count; i++) {
				ProjectFilePattern pattern = (ProjectFilePattern)IncludedFilesPatterns_ [i];

				// Look thru the list of folders and remove children of 
				// this one. Also if we have parent of this one then we should
				// don't add it.
				for (int j = 0; !Canceled_ && j < TopFolders_.Count;) {
					ProjectFile file = (ProjectFile)TopFolders_.GetByIndex (j);
					string path = file.FullPath + Path.DirectorySeparatorChar;
					if (pattern.FullFolderPath.StartsWith (path)) {
						// the item is parent, quit
						pattern = null;
						break;
					} else if (path.StartsWith (pattern.FullFolderPath)) {
						// item is child, remove it
						TopFolders_.RemoveAt (j);
					} else {
						j++;
					}
				}
				
				if (pattern == null) {
					continue;
				}
		
				// if we are here, we need to add the new top level folder
				TopFolders_.Add (pattern.FullFolderPath, new ProjectFile (pattern.FolderPath, 
						 pattern.FullFolderPath, String.Empty, true));
			}
		}
		
		void AppendFolder (ProjectFile file)
		{
			Status = String.Format ("Loading folder {0}", file.FullPath);
			
			// first check if path itself matches 
			if (Canceled_ || !ProjectFilePattern.IsMatch (IncludedFilesPatterns_, file.FullPath, true)) {
				// Console.WriteLine ("AppendFolder: folder {0} is not in included folders list", file.FullPath);
			 	return;
			}
			if (Canceled_ || ProjectFilePattern.IsMatch (ExcludedFilesPatterns_, file.FullPath, false)) {
				// Console.WriteLine ("AppendFolder: folder {0} is in excluded folders list", file.FullPath);
			 	return;
			}

			Monitor.Enter (this);
			Folders_.Add (file.FullPath, file);
			Monitor.Exit (this);
			
			// all children files
			try {
				AddChildrenFiles (file.FullPath);
			} catch (Exception exception) {
				Errors_ = true;
			}

			// all children folders
			try {
				AddChildrenFolders (file.FullPath);
			} catch (Exception exception) {
				Errors_ = true;
			}

		}

		void AddChildrenFiles (string parent)
		{
			// Console.WriteLine ("AddChildrenFiles: {0}", parent);
			string[] files = Directory.GetFiles (parent);
			if (files == null) {
				return;
			}

			for (int i = 0; !Canceled_ && i < files.Length; i++) {		
				string path = files [i];
				// match the file against included/excluded list
				if (Canceled_ || !ProjectFilePattern.IsMatch (IncludedFilesPatterns_, path, true)) {
					 continue;
				}
				if (Canceled_ || ProjectFilePattern.IsMatch (ExcludedFilesPatterns_, path, false)) {
					continue;
				}
				
				Monitor.Enter (this);		
				Files_.Add (path, new ProjectFile (path, parent, false));	
				Monitor.Exit (this);		
			}
		}

		void AddChildrenFolders (string parent)
		{
			// Console.WriteLine ("AddChildrenFolders: {0}", parent);
			string[] directories = Directory.GetDirectories (parent);
			if (directories == null) {
				return;
			}
			for (int i = 0; !Canceled_ && i < directories.Length; i++) {
				AppendFolder (new ProjectFile (directories [i], parent, true));
			}
		}
		
		public string Status {
			get {
				string res;
				Monitor.Enter (this);
				res = Status_;
				Monitor.Exit (this);
				return res;
			}
			set {
				Monitor.Enter (this);
				Status_ = value;
				Monitor.Exit (this);
			}
		}

		public bool IsFinished {
			get {
				bool res;
				Monitor.Enter (this);
				res = IsFinished_;
				Monitor.Exit (this);
				return res;
			}
			set {
				Monitor.Enter (this);
				IsFinished_ = value;
				Monitor.Exit (this);
			}
		}
		
		public int FilesCount
		{
			get {
				int res;
				Monitor.Enter (this);
				res = Files_.Count;
				Monitor.Exit (this);
				return res;
			}
		}
		
		public ProjectFile GetFile (int index) 
		{
			ProjectFile res;
			Monitor.Enter (this);
			res = (ProjectFile)Files_.GetByIndex (index);
			Monitor.Exit (this);
			
			return res;
		}

		public ProjectFile GetFile (string path) 
		{
			ProjectFile res;
			Monitor.Enter (this);
			res = (ProjectFile)Files_ [path];
			Monitor.Exit (this);
			
			return res;
		}

		public int FoldersCount 
		{
			get {
				int res;
				Monitor.Enter (this);
				res = Folders_.Count;
				Monitor.Exit (this);
				return res;
			}
		}
		
		public ProjectFile GetFolder (int index) 
		{
			ProjectFile res;
			Monitor.Enter (this);
			res = (ProjectFile)Folders_.GetByIndex (index);
			Monitor.Exit (this);
			
			return res;
		}

		public ProjectFile GetFolder (string path) 
		{
			ProjectFile res;
			Monitor.Enter (this);
			res = (ProjectFile)Folders_ [path];
			Monitor.Exit (this);
			
			return res;
		}

	}

	class ProjectFilePattern {
		public string Pattern_ 	= null;
		public string FileName_ = null;
		public string FolderPath_ 	= null;
		public string FullFolderPath_ 	= null;
		SearchPattern SearchPattern_;
	
		public ProjectFilePattern (string root, string pattern)
		{
			Pattern_ 	= pattern.Trim ();
			FileName_ 	= Path.GetFileName (Pattern_);
			if (FileName_ == null || FileName_ == String.Empty) {
				FileName_ = "*";
			}		
			FolderPath_ 	= Path.GetDirectoryName (Pattern_);
			FullFolderPath_	= FolderPath_;
			if (!Path.IsPathRooted (FullFolderPath_)) {
				FullFolderPath_ = Path.Combine (root, FullFolderPath_);
		    	}
			FullFolderPath_	= Path.GetFullPath (FullFolderPath_);
			SearchPattern_ 	= new SearchPattern (FileName_);
		}

		static public bool IsMatch (ArrayList patterns, string path, bool defResult)
		{
			for (int i = 0; i < patterns.Count; i++) {
				if (((ProjectFilePattern)patterns [i]).IsMatch (path, defResult)) {
					return true;
				}
			}
			return false;
		}		
	
		public bool IsMatch (string path, bool defResult)
		{
			if (!path.StartsWith (FullFolderPath_)) {
				// Console.WriteLine ("ProjectFilePattern.IsMatch - no point1: pattern={0}, path={1}", Pattern_, path);
				return false;
			}
			if (path.Length > FullFolderPath_.Length && path [FullFolderPath_.Length] != Path.DirectorySeparatorChar) {
				// Console.WriteLine ("ProjectFilePattern.IsMatch - no point2: pattern={0}, path={1}", Pattern_, path);
				return false;
			}
			path = path.Substring (FullFolderPath_.Length);
		
			for (int level = 0; path.Length > 0; level++) {
				int pos = path.LastIndexOf (Path.DirectorySeparatorChar);
				if (pos < 0) {
					break;
				}
				string name = path.Substring (pos + 1);
				path = path.Substring (0, pos);
				
				// don't match folder names agains patterns with extension
				// for example, if user specified "*.cs" this means
				// all *.cs, not all folders with *.cs
				if (level > 0 && name.IndexOf ('.') == -1 && FileName_.IndexOf ('.') > 0) {
					// Console.WriteLine ("ProjectFilePattern.IsMatch - {2} point3: pattern={0}, path={1}", Pattern_, path, defResult);
					return defResult;
				}
				
				if (SearchPattern_.IsMatch (name)) {
					// Console.WriteLine ("ProjectFilePattern.IsMatch - yes point4: pattern={0}, path={1}", Pattern_, path);
					return true;
				}
			}
		
			// Console.WriteLine ("ProjectFilePattern.IsMatch - {2} point5: pattern={0}, path={1}", Pattern_, path, defResult);
			return defResult;
		}
		
		public string FolderPath 
		{
			get {
				return FolderPath_;
			} 
		}

		public string FullFolderPath 
		{
			get {
				return FullFolderPath_;
			} 
		}
	}

	//
	// System.IO.SearchPattern.cs: Filename glob support.
	//
	// Author:
	//   Dan Lewis (dihlewis@yahoo.co.uk)
	//
	// (C) 2002
	//
	
	// FIXME: there's a complication with this algorithm under windows.
	// the pattern '*.*' matches all files (i think . matches the extension),
	// whereas under UNIX it should only match files containing the '.' character.

	class SearchPattern {
		public SearchPattern (string pattern) : this (pattern, false) { }

		public SearchPattern (string pattern, bool ignore)
		{
			this.ignore = ignore;
			Compile (pattern);
		}

		public bool IsMatch (string text)
		{
			return Match (ops, text, 0);
		}

		// private

		private SearchPatternOp ops;		// the compiled pattern
		private bool ignore;	// ignore case

		private void Compile (string pattern)
		{
			if (pattern == null || pattern.IndexOfAny (InvalidChars) >= 0)
				throw new ArgumentException ("Invalid search pattern.");

			if (pattern == "*") {	// common case
				ops = new SearchPatternOp (SearchPatternOpCode.True);
				return;
			}

			ops = null;

			int ptr = 0;
			SearchPatternOp last_op = null;
			while (ptr < pattern.Length) {
				SearchPatternOp op;
			
				switch (pattern [ptr]) {
				case '?':
					op = new SearchPatternOp (SearchPatternOpCode.AnyChar);
					++ ptr;
					break;

				case '*':
					op = new SearchPatternOp (SearchPatternOpCode.AnyString);
					++ ptr;
					break;
					
				default:
					op = new SearchPatternOp (SearchPatternOpCode.ExactString);
					int end = pattern.IndexOfAny (WildcardChars, ptr);
					if (end < 0)
						end = pattern.Length;

					op.Argument = pattern.Substring (ptr, end - ptr);
					if (ignore)
						op.Argument = op.Argument.ToLower ();

					ptr = end;
					break;
				}

				if (last_op == null)
					ops = op;
				else
					last_op.Next = op;

				last_op = op;
			}

			if (last_op == null)
				ops = new SearchPatternOp (SearchPatternOpCode.End);
			else
				last_op.Next = new SearchPatternOp (SearchPatternOpCode.End);
		}

		private bool Match (SearchPatternOp op, string text, int ptr)
		{
			while (op != null) {
				switch (op.Code) {
				case SearchPatternOpCode.True:
					return true;

				case SearchPatternOpCode.End:
					if (ptr == text.Length)
						return true;

					return false;
				
				case SearchPatternOpCode.ExactString:
					int length = op.Argument.Length;
					if (ptr + length > text.Length)
						return false;

					string str = text.Substring (ptr, length);
					if (ignore)
						str = str.ToLower ();

					if (str != op.Argument)
						return false;

					ptr += length;
					break;

				case SearchPatternOpCode.AnyChar:
					if (++ ptr > text.Length)
						return false;
					break;

				case SearchPatternOpCode.AnyString:
					while (ptr <= text.Length) {
						if (Match (op.Next, text, ptr))
							return true;

						++ ptr;
					}

					return false;
				}

				op = op.Next;
			}

			return true;
		}

		// private static

		private static readonly char [] WildcardChars = { '*', '?' };
		private static readonly char [] InvalidChars = { Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar };

	}

	class SearchPatternOp {
		public SearchPatternOp (SearchPatternOpCode code)
		{
			this.Code = code;
			this.Argument = null;
			this.Next = null;
		}
		
		public SearchPatternOpCode Code;
		public string Argument;
		public SearchPatternOp Next;
	}

	enum SearchPatternOpCode {
		ExactString,		// literal
		AnyChar,		// ?
		AnyString,		// *
		End,			// end of pattern
		True			// always succeeds
	}

}
