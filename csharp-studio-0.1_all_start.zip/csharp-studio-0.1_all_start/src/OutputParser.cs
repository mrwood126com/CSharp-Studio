///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using Gtk;
using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace CSharpStudio
{
	enum OutputLineType {
		Unknown,
		EnterFolder,
		LeaveFolder,
		Error,
		Warning,
		SearchResult
	}
	
	class OutputLine 
	{
		OutputLineTemplate Template_;
		String Folder_;
		String FileName_;
		int LineNumber_;

		public OutputLine (OutputLineTemplate template, string folder, string filename, int line)
		{
			Template_ = template;
			Folder_ = folder;
			FileName_ = filename;
			LineNumber_ = line;
		}
		public OutputLineTemplate Template {
			get {
				return Template_;
			}
		}
		
		public string Folder {
			get {
				return Folder_;
			}
		}

		public string FileName {
			get {
				return FileName_;
			}
		}

		public int LineNumber {
			get {
				return LineNumber_;
			}
		}
		
		public string TagName {
			get {
				return Template_.TagName;
			}
		}
	}
	
	class OutputParser
	{
		Hashtable ClickableLines_;
		Stack Folders_;
		string TopFolder_ = null;

		public static TextTagTable CreateTagTable ()
		{
			return OutputLineTemplate.CreateTagTable ();
		}		
		
		public OutputParser ()
		{
			ClickableLines_ = new Hashtable ();
			Folders_ = new Stack ();
		}
		
		public void Clear ()
		{
			ClickableLines_.Clear ();
			Folders_.Clear ();
		}
		
		public OutputLine ParseLine (string str, int line) 
		{
			// get cur folder
			string curFolder = (Folders_.Count > 0) ? (string)Folders_.Peek () : null;
			
			// find the matching template			
			OutputLine res = OutputLineTemplate.MatchLine (str, curFolder, TopFolder_);
			if (res == null) {
				return null;
			}
			
			// remember clickable lines
			// Console.WriteLine ("ParseLine: line {0}, clickable {1}", line, res.Template.Clickable);
			if (res.Template.Clickable) {
				ClickableLines_ [line] = res;
			}
			
			// update folders stack if needed
			if (res.Template.Type == OutputLineType.EnterFolder) {
				Folders_.Push (res.Folder);
			} else if (res.Template.Type == OutputLineType.LeaveFolder) {
				Folders_.Pop ();
			}
			return res;
		}
		
		public OutputLine GetLine (int line) 
		{
			return (OutputLine) ClickableLines_ [line];
		}
		
		public string TopFolder {
			set {
				TopFolder_ = value;
			}
		}
	}	

	class OutputLineTemplate 
	{
		public static ArrayList TemplatesList;
		
		OutputLineType Type_;
		string Name_;
		string TagName_ = null;
		bool Clickable_ = false;
		Regex RegularExpression_ = null;
		int FolderPos_ = -1;
		int FileNamePos_ = -1;
		int LinePos_ = -1;
		
		string TagColor_ = null;  // todo: use rc style file
		
		static OutputLineTemplate ()
		{
			OutputLineTemplate tmpl;

			// todo: read from file?
			TemplatesList = new ArrayList();
			
			// make: entering folder
			tmpl =  new OutputLineTemplate (OutputLineType.EnterFolder, "make-enter-folder", 
							@"^make\[.*\]: Entering directory \`(.*)\'$");
			tmpl.FolderPos_ = 1;
			tmpl.TagColor_ = "green";
			TemplatesList.Add (tmpl);

			// make: leaving folder
			tmpl =  new OutputLineTemplate (OutputLineType.LeaveFolder, "make-leave-folder", 
							@"^make\[.*\]: Leaving directory *\`(.*)\'$");
			tmpl.FolderPos_ = 1;
			tmpl.TagColor_ = "green";
			TemplatesList.Add (tmpl);

			// mcs: error
			tmpl =  new OutputLineTemplate (OutputLineType.Error, "mcs-error", 
							@"^ *([^\(]*)\((\d+)\) +error +([^:]*): *(.*)$");
			tmpl.Clickable = true;
			tmpl.FileNamePos_ = 1;
			tmpl.LinePos_ = 2;
			// tmpl.MessageId_ = 3;
			// tmpl.MessageDetails_ = 4; 
			tmpl.TagColor_ = "red";
			TemplatesList.Add (tmpl);

			// mcs: warning
			tmpl =  new OutputLineTemplate (OutputLineType.Error, "mcs-warning", 
							@"^ *([^\(]*)\((\d+)\) +warning +([^:]*): *(.*)$");
			tmpl.Clickable = true;
			tmpl.FileNamePos_ = 1;
			tmpl.LinePos_ = 2;
			// tmpl.MessageId_ = 3;
			// tmpl.MessageDetails_ = 4; 
			tmpl.TagColor_ = "orange";
			TemplatesList.Add (tmpl);
		
			// grep
			tmpl =  new OutputLineTemplate (OutputLineType.Error, "grep", 
							@"^([^:]*):(\d+): *(.*)$");
			tmpl.Clickable = true;
			tmpl.FileNamePos_ = 1;
			tmpl.LinePos_ = 2;
			// tmpl.MessageDetails_ = 4; 
			// tmpl.TagColor_ = "blue";
			TemplatesList.Add (tmpl);
		}

		public static TextTagTable CreateTagTable ()
		{
			TextTagTable table = new TextTagTable();
			
			for (int i = 0; i < TemplatesList.Count; i++) {
				TextTag tag = ((OutputLineTemplate)TemplatesList [i]).CreateTag ();
				if (tag != null) {
					table.Add (tag);
				}
			}
			
			return table;
		}

		static public OutputLine MatchLine (string str, string curFolder, string topFolder) 
		{
			// Console.WriteLine ("MatchLine: {0}", str);	
			for (int i = 0; i < TemplatesList.Count; i++) {
				OutputLine res = ((OutputLineTemplate)TemplatesList [i]).Match (str, curFolder, topFolder);
				if (res != null) {
					return res;
				}
			}
			return null;
		}
		
		public OutputLineTemplate (OutputLineType type, string name, string regex)
		{
			Type_ = type;
			Name_ = name;
			TagName_ = name;
			RegularExpression_ = new Regex (regex);
		}
		
		public OutputLine Match (string str, string curFolder, string topFolder)
		{
			if (RegularExpression_ == null) {
				return null;
			}

			Match match = RegularExpression_.Match (str);
			if (match == null || !match.Success) {
				return null;
			}
			
			// Console.WriteLine ("Match {0}:", Name);			
			string folder = null;
			string filename = null;
			int line = -1;
			for (int i = 0; i < match.Groups.Count; i++) {
				// Console.WriteLine ("Match (group {0}): {1}", i, match.Groups [i].Value);
				if (i == FolderPos_) {
					folder = match.Groups [i].Value;
				} else if (i == FileNamePos_) {
					filename = match.Groups [i].Value;
				} else if (i == LinePos_) {
					line = Convert.ToInt32 (match.Groups [i].Value);
				}
			}
			
			// construct full filename and folder paths
			if (filename != null && !Path.IsPathRooted (filename) && folder != null) {
				filename = Path.Combine (folder, filename);
			}
			if (filename != null && !Path.IsPathRooted (filename) && curFolder != null) {
				filename = Path.Combine (curFolder, filename);
			}
			if (filename != null && !Path.IsPathRooted (filename) && topFolder != null) {
				filename = Path.Combine (topFolder, filename);
			}
			if (filename != null) {
				filename = Path.GetFullPath (filename);
			}

			if (folder != null && !Path.IsPathRooted (folder) && curFolder != null) {
				folder = Path.Combine (curFolder, folder);
			}
			if (folder != null && !Path.IsPathRooted (folder) && topFolder != null) {
				folder = Path.Combine (topFolder, folder);
			}
			if (folder != null) {
				folder = Path.GetFullPath (folder);
			}

			// Console.WriteLine ("Match: folder: {0}, file: {1}, line: {2}", folder, filename, line);
			return new OutputLine (this, folder, filename, line);
		}
		
		public TextTag CreateTag ()
		{
			// todo: use rc style file
			if (TagName == null || TagColor == null) {
				return null;
			}
			
			TextTag tag = new TextTag (TagName);
			if (TagColor != null) {
				tag.Foreground = TagColor; 
			}
			return tag;
		}

		public string Name {
			get {
				return Name_;
			}
		}
		
		public OutputLineType Type {
			get {
				return Type_;
			}
		}
		
		public string TagName {
			get {
				return TagName_;
			} 
			
			set {
				TagName_ = value;
			}
		}
		
		// todo: use rc style file
		public string TagColor {
			get {
				return TagColor_;
			}
			
			set {
				TagColor_ = value;
			}
		}
		
		public bool Clickable {
			get {
				return Clickable_;
			}
			
			set {
				Clickable_ = value;
			}
		}
	}


}
