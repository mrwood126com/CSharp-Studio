///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.IO;

namespace CSharpStudio {

public class YesNoCancelDialog : ModalDialog {
        public YesNoCancelDialog (Gtk.Window parent, string message, string title) : 	
		base (parent, "yes_no_cancel_dialog")
        {
		Dialog_.Title = title;
		
		Gtk.Label messageLabel = (Gtk.Label)GladeXml_ ["yes_no_cancel_dialog_message_label"];
		messageLabel.Text = message;
    	}
}

}
