///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace CSharpStudio {

public class OutputView {
	int Pos_;
	TextView View_;	
	OutputParser Parser_;
	bool Canceled_ = false;
	
	Process Process_ = null;
	OutputFetchThread StdoutThread_ = null;
	OutputFetchThread StderrThread_ = null;
	ArrayList OutputBuffer_ = null;
		
        public OutputView (TextView view, int pos)
        {
		Pos_ = pos;		
		View_ = view;
		View_.FocusInEvent += new FocusInEventHandler (on_focus_in_cb);
		View_.FocusOutEvent += new FocusOutEventHandler (on_focus_out_cb);
		View_.ButtonPressEvent += new ButtonPressEventHandler (on_button_press_cb);
		Buffer = new TextBuffer(OutputParser.CreateTagTable ());
		
		Parser_ = new OutputParser ();
		OutputBuffer_ = new ArrayList ();
	}

	 public void UpdateUI ()
	{	
		// edit
		Studio.MainMenu.EnableItem ("edit_undo", false);
		Studio.MainMenu.EnableItem ("edit_redo", false);

		Studio.MainMenu.EnableItem ("edit_cut", HasSelection);
		Studio.MainMenu.EnableItem ("edit_copy", HasSelection); // todo: selection
		Studio.MainMenu.EnableItem ("edit_paste", false);
		Studio.MainMenu.EnableItem ("edit_clear", false);

		Studio.MainMenu.EnableItem ("edit_find", false); // todo: find
		Studio.MainMenu.EnableItem ("edit_replace", false);
		
		Studio.MainToolbar.EnableItem ("undo_button", false);
		Studio.MainToolbar.EnableItem ("redo_button", false);

		Studio.MainToolbar.EnableItem ("cut_button", false);
		Studio.MainToolbar.EnableItem ("copy_button", true); // todo: selection
		Studio.MainToolbar.EnableItem ("paste_button", false);

		Studio.MainToolbar.EnableItem ("find_hbox", false); // todo: find		
		Studio.MainToolbar.EnableItem ("find_files_button", false); // todo: find
	}
	
	public void Run (string command, string folder) 
	{
		if (IsRunning) {
			Console.WriteLine ("killing the process...");
			Canceled_ = true;
			Stop ();
			return;
		}
		Canceled_ = false;
		Buffer.Clear ();
		Parser_.Clear ();
		Parser_.TopFolder = folder;
		
		ProcessStartInfo pi = new ProcessStartInfo (null, command);
		pi.WorkingDirectory = folder;
		pi.UseShellExecute = true;
		pi.CreateNoWindow = true;
		pi.ErrorDialog = false;
		pi.RedirectStandardOutput = true;
		pi.RedirectStandardError = true;
		Process_ = new System.Diagnostics.Process();
		Process_.EnableRaisingEvents = true;
		Process_.Exited += new EventHandler (on_process_exited_cb);
		Process_.StartInfo = pi;
		Process_.Start ();
		
		StdoutThread_ = new OutputFetchThread (Process_, Process_.StandardOutput, OutputBuffer_);
		StderrThread_ = new OutputFetchThread (Process_, Process_.StandardError, OutputBuffer_);

		GLib.Idle.Add (new GLib.IdleHandler (update_view_cb));
		Studio.UpdateUI ();
	}


	void on_button_press_cb (object o, ButtonPressEventArgs args)
	{		
		try {
			if (args.Event.type == EventType.TwoButtonPress && View_.GetWindowType (args.Event.window) == TextWindowType.Text) {
				TextIter iter;
				int x, y, y_top;
				
				View_.WindowToBufferCoords (TextWindowType.Text, (int)args.Event.x, (int)args.Event.y, out x, out y);
				View_.GetLineAtY (out iter, y, out y_top);
				
				OutputLine line = Parser_.GetLine (iter.Line);
				if (line != null) {
					Studio.GotoLine (line.FileName, line.LineNumber);
				}
				((SignalArgs)args).RetVal = true;
			}
		} catch (System.IO.FileNotFoundException exception) {
			Studio.ShowError (exception.Message);
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}

	void on_focus_in_cb (object o, FocusInEventArgs args)
	{		
		try {
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}

	void on_focus_out_cb (object o, FocusOutEventArgs args)
	{		
		try {
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}

	bool update_view_cb ()
	{
		bool cont = false;
		try {
			if (IsRunning) {
				UpdateView ();
				cont = true;
			} else {
				Stop ();
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		return cont;
	}

	void on_process_exited_cb (object o, EventArgs args)
	{		
		Console.WriteLine ("on_process_exited_cb");
		try {
			if (!Canceled_) {
				Stop ();
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
	}

        void UpdateView () {
		int i;
			
		ArrayList strings = new ArrayList ();		
		Monitor.Enter (OutputBuffer_);
		for (i = 0; i < OutputBuffer_.Count; i++) {
			strings.Add ((string)OutputBuffer_ [i]);
		}
		OutputBuffer_.Clear ();
		Monitor.Exit (OutputBuffer_);
		 
		if (strings.Count == 0) {
			return;
		}
		
		for (i = 0; i < strings.Count; i++) {
			string str = (string)strings [i];
		    	Buffer.Insert (Buffer.EndIter, str + "\n");
			
			OutputLine line = Parser_.ParseLine (str, Buffer.LineCount - 2);
			if (line != null && line.TagName != null) {
				TextIter iter;
				Buffer.GetIterAtLine (out iter, Buffer.LineCount - 2);
				Buffer.ApplyTag (line.TagName, iter, Buffer.EndIter);
			}
		}
		View_.ScrollToMark (Buffer.InsertMark, 0.0, false, 1.0, 0);
	}
	
	void Stop () {
		if (Process_ == null) {
			return;
		}		
		Process process = Process_;
		Process_ = null;
		
		Console.WriteLine ("Process: {0}, {1}", IsRunning, process.Responding); 
		if (!process.HasExited && process.Responding && process.CloseMainWindow ()) {
			Console.WriteLine ("Wait for main window close"); 
			process.WaitForExit (100);
		}
		if (!process.HasExited) {
			Console.WriteLine ("Wait for kill"); 
			process.Kill ();
			process.WaitForExit (100);
		}
		
		int exitCode = process.ExitCode;
		process.Close ();
		process	 = null;
		
		if (StdoutThread_ != null) {
			StdoutThread_.Stop ();
		}
		StdoutThread_ = null;
		
		if (StderrThread_ != null) {
			StderrThread_.Stop ();
		}
		StderrThread_ = null;
		
		UpdateView ();
		Studio.UpdateUI ();
		if (Canceled_ ) {		
			Buffer.Insert (Buffer.EndIter, "\nThe process is canceled by user.\n");
		} else if (exitCode != 0) {
			Buffer.Insert (Buffer.EndIter, String.Format ("\nThe process exited with code {0}.\n", exitCode));
		} else {
			Buffer.Insert (Buffer.EndIter, "\nThe process is finished.\n");
		}
		View_.ScrollToIter (Buffer.EndIter, 0, false, 0, 0);
	}

	public int Pos {
		get {
			return Pos_;
		}
	}

	public bool IsRunning {
		get {
			// Console.WriteLine ("IsRunning: " + (Process_ != null && !Process_.HasExited));
			return Process_ != null && !Process_.HasExited;
		}
	}

	public void Copy (Clipboard clipboard) 
	{
		if (!HasFocus) {
			return;
		}
		Buffer.CopyClipboard (clipboard);
	}

	public void Clear () 
	{
		if (!HasFocus) {
			return;
		}
		Buffer.Clear ();
	}
		
	protected TextBuffer Buffer {
		get {
			return (TextBuffer)View_.Buffer;
		}
		
		set {
			View_.Buffer = value;
		}
	}
	
	public bool HasFocus
	{
		get {
			return View_.HasFocus;
		}
	}

	public bool HasSelection
	{
		get {
			TextIter start, end;
			if (!View_.Buffer.GetSelectionBounds (out start, out end)) {
				return false;
			}
			return start.Offset != end.Offset;
		}
	}
		
}


internal class OutputFetchThread {
	Process Process_;
	StreamReader Stream_;
	ArrayList OutputBuffer_;
	ManualResetEvent StopEvent_;
	ManualResetEvent FinishedEvent_;
	Thread Thread_;
	
	public OutputFetchThread (Process process, StreamReader stream, ArrayList buffer)
	{
	        Process_ = process;
		Stream_ = stream;
		OutputBuffer_ = buffer;
		StopEvent_ = new ManualResetEvent (false);
		FinishedEvent_ = new ManualResetEvent (false);
		Thread_ = new Thread(new ThreadStart(FetchThreadFunc));
		Thread_.Start ();
	}
	
	public void FetchThreadFunc ()
	{
		string str;
		int i = 0;
		do {
			str = Stream_.ReadLine ();
			if (str != null) {
				Monitor.Enter (OutputBuffer_);
				OutputBuffer_.Add (str);
				Monitor.Exit (OutputBuffer_);
			}
		} while (!Process_.HasExited && !StopEvent_.WaitOne(0, true));
		
		// need to pick up everything
		while ((str = Stream_.ReadLine ()) != null) {
			Monitor.Enter (OutputBuffer_);
			OutputBuffer_.Add (str);
			Monitor.Exit (OutputBuffer_);
		}
		
		FinishedEvent_.Set ();		
		// Console.WriteLine ("FetchThreadFunc: exit");
	}
	
	public void Stop ()
	{
		StopEvent_.Set ();
		
		// wait 100 msec at most
		if (Thread_.IsAlive) {
			WaitHandle.WaitAll( (new ManualResetEvent[] { FinishedEvent_ }), 100, true); 
		}
	}
}
}
