///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using System;
using System.IO;

namespace CSharpStudio {
	public class SafeStreamWriter : StreamWriter {
		string Path_;
		string BakPath_;
	
        	public SafeStreamWriter (string path) : base (String.Format ("{0}.bak", path))
       		{
        		Path_ = path;
        		BakPath_ = String.Format ("{0}.bak", path);
		}
	
		public override void Close ()
		{
			base.Close ();
			File.Copy (BakPath_, Path_, true);
			// File.Delete (BakPath_);
		}
	}
}
