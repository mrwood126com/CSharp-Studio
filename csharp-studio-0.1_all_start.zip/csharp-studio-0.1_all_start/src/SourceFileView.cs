///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using Gdk;
using GConf;
using Glade;
using Gnome;
using Gtk;
using GtkSharp;
using Pango;
using System;
using System.IO;

namespace CSharpStudio {

public class SourceFileView : FileView {
	static SourceLanguagesManager LanguagesManager_ = new SourceLanguagesManager ();

	ScrolledWindow ScrolledWindow_;
	SourceView View_;
	int InsertMarkOffset_ = -1;
	int SelectionBoundOffset_ = -1;
	
        public SourceFileView () 
        {
		ScrolledWindow_ = new ScrolledWindow (null, null);
		ScrolledWindow_.SetPolicy(PolicyType.Automatic,PolicyType.Automatic);
		ScrolledWindow_.BorderWidth = 2;
		
		View_ = new SourceView();
		View_.FocusInEvent += new FocusInEventHandler (on_focus_in_cb);
		View_.FocusOutEvent += new FocusOutEventHandler (on_focus_out_cb);
		View_.LeftMargin = View_.RightMargin = View_.PixelsBelowLines = View_.PixelsAboveLines = 4;
		View_.BorderWidth = 2;
		UpdateEditorSettings ();

		Buffer.ModifiedChanged += new EventHandler (on_modified_changed_cb);
		Buffer.MarkSet += new MarkSetHandler (on_mark_set_cb);
		ScrolledWindow_.Add(View_);

		Settings.EditorSettingsChanged += new NotifyEventHandler (editor_settings_changed_cb);
		ReloadProject ();
	}

	override public void ReloadProject ()
	{
		if (Studio.Project == null) {
			return;
		}
		
		if (View_.TabsWidth != Studio.Project.TabsWidth) {
			View_.TabsWidth = Studio.Project.TabsWidth;
		}
		if (View_.InsertSpacesInsteadOfTabs != Studio.Project.FillTabs) {
			View_.InsertSpacesInsteadOfTabs = Studio.Project.FillTabs;
		}
	}

	override public void UpdateUI ()
	{
		base.UpdateUI ();
		
		Studio.MainMenu.EnableItem ("edit_undo", Buffer.CanUndo ());
		Studio.MainMenu.EnableItem ("edit_redo",  Buffer.CanRedo ());		    
		Studio.MainMenu.EnableItem ("edit_cut", HasSelection); 
		Studio.MainMenu.EnableItem ("edit_copy", HasSelection); 
		Studio.MainMenu.EnableItem ("edit_paste", true); // todo: can paste?
		Studio.MainMenu.EnableItem ("edit_clear", true); // todo: is empty
		Studio.MainMenu.EnableItem ("edit_find",  true);
		Studio.MainMenu.EnableItem ("edit_replace", true);

	    	Studio.MainToolbar.EnableItem ("undo_button", Buffer.CanUndo ());			
		Studio.MainToolbar.EnableItem ("redo_button", Buffer.CanRedo ());

		Studio.MainToolbar.EnableItem ("cut_button", true); // todo: can cut?
	    	Studio.MainToolbar.EnableItem ("copy_button", true);  // todo: can copy?
		Studio.MainToolbar.EnableItem ("paste_button", true); // todo: can paste?
		
		UpdateAppBar ();
	}
		
	void UpdateAppBar ()
	{
		TextIter iter;
		Buffer.GetIterAtMark (out iter, Buffer.InsertMark);
		Studio.MainAppBar.SetRowAndColumn (iter.Line + 1, iter.VisibleLineOffset + 1);
	}

	override public void OpenFile (string path)
	{
		if (path == Path) {
			return;
		}
		
		SourceBuffer buffer = new SourceBuffer(new SourceTagTable());
		if (path != null && path != String.Empty) {
			StreamReader sr = new StreamReader(path);

			buffer.BeginNotUndoableAction ();
			buffer.Text = sr.ReadToEnd ();
			sr.Close ();
			Buffer = buffer;
			buffer.EndNotUndoableAction ();
		}
		Buffer.ModifiedChanged += new EventHandler (on_modified_changed_cb);
		Buffer.Modified = false;
		Path = path;
	}
	
	override public void SaveFile (string path)
	{
		StreamWriter sw = new SafeStreamWriter(path);
		sw.Write (Buffer.Text);
		sw.Close ();
		Path = path;
		Buffer.Modified = false;
	}

	override public void GotoLine (int line)
	{
		TextIter iter;
		Buffer.GetIterAtLine (out iter, (line > 0) ? line - 1: 0);
		Buffer.PlaceCursor (iter);
		View_.ScrollToMark (Buffer.InsertMark, 0.25, true, 0.0, 0.5);
		View_.GrabFocus ();
	}

	override public void Copy (Clipboard clipboard) 
	{
		Buffer.CopyClipboard (clipboard);
	}

	override public void Cut (Clipboard clipboard) 
	{
		Buffer.CutClipboard (clipboard, true);
	}

	override public void Paste (Clipboard clipboard) 
	{
		// todo: replace this with 
		// 	Buffer.PasteClipboard (clipboard
		// when upgrade to new gtk-sharp
		TextIter iter;
		Buffer.GetIterAtMark(out iter, Buffer.InsertMark);
		Buffer.PasteClipboard (clipboard, iter, true);
	}
	
	override public void Clear ()
	{
		Buffer.Clear ();
	}
	
	override public void Undo ()
	{
		Buffer.Undo ();
	}

	override public void Redo ()
	{
		Buffer.Redo ();
	}

	override public void PrepareFindOrReplace (bool replace)
	{
		// remember selection
		TextIter insertMark, selectionBound;
		Buffer.GetIterAtMark (out insertMark, Buffer.InsertMark);
		Buffer.GetIterAtMark (out selectionBound, Buffer.SelectionBound);
		InsertMarkOffset_ 	= insertMark.Offset;
		SelectionBoundOffset_	= selectionBound.Offset;
	}
	
	override public bool FindOrReplace (bool replace)
	{
		// get current cursor position
		
		// prepare flags
		SourceSearchFlags flags = SourceSearchFlags.VisibleOnly;
		if (!Settings.FindRepaceWithCase) {
			flags |= SourceSearchFlags.CaseInsensitive;
		}
		
		// find start position
		TextIter cursor;
		int left = (InsertMarkOffset_ <= SelectionBoundOffset_) ? InsertMarkOffset_ : SelectionBoundOffset_;
		int right = (InsertMarkOffset_ <= SelectionBoundOffset_) ? SelectionBoundOffset_ : InsertMarkOffset_;
		if (Settings.FindRepaceBackwards) {
			Buffer.GetIterAtOffset (out cursor, (replace) ? right : left);
		} else {
			Buffer.GetIterAtOffset (out cursor, (replace) ? left : right);
		}
		
		// do search
		bool result = false;
		TextIter start, end;
		while (true) {
			if (Settings.FindRepaceBackwards) {
				result = Buffer.BackwardSearch (cursor, 
						Settings.FindReplaceFindString, flags,
						out start, out end, Buffer.StartIter); // todo: do in pieces!  
			} else {
				result = Buffer.ForwardSearch (cursor, 
						Settings.FindReplaceFindString, flags,
						out start, out end, Buffer.EndIter); // todo: do in pieces!  
			}
			if (!result || !Settings.FindRepaceWholeWords) {
				break;
			}
			if (start.StartsWord () && end.EndsWord ()) {
				break;
			}
			cursor = (Settings.FindRepaceBackwards) ? start : end;
		}
		
		// if found: highlight
		if (result) {
			// Console.WriteLine ("SourceFileView: found!");
			Buffer.PlaceCursor(start);
			Buffer.MoveMark (Buffer.SelectionBound, end);
			View_.ScrollToMark (Buffer.InsertMark, 0.45, true, 0.5, 0.0);
		}	
		
		// show replace prompt if needed
		if (result && replace && Settings.FindRepacePrompt) {
			ReplacePromptDialog dialog = new ReplacePromptDialog (Studio.MainWindow);
			switch (dialog.Run ()) {
			case ResponseType.Yes:
				break;
			case ResponseType.No:
				replace = false;
				if (Settings.FindRepaceBackwards && Settings.FindRepaceAll) {
					Buffer.PlaceCursor (start);
				} else {
					Buffer.PlaceCursor (end);
				}
				break;
			case ResponseType.Apply:
				break;
			default:
				result = false;
				break;
			}
		}
			
		// replace
		if (result && replace) {
			Buffer.DeleteSelection (false, true);
			Buffer.InsertAtCursor (Settings.FindReplaceReplaceString);
		}
		
		return result;
	}

	void UpdateEditorSettings ()
	{
		View_.ShowLineNumbers	= Settings.ShowLineNumbers;
		View_.AutoIndent	= Settings.EnableAutoIndent;
		View_.SmartHomeEnd 	= Settings.EnableSmartHomeEnd;
		if (Settings.EditorFontName != String.Empty) {
			View_.ModifyFont (FontDescription.FromString (Settings.EditorFontName));
		}
	}
		   
	void on_modified_changed_cb (object o, EventArgs args)
	{		
		try {
			UpdateAppBar ();
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}

	void on_mark_set_cb (object o, MarkSetArgs args)
	{		
		try {
			if (HasFocus && args.Mark == Buffer.InsertMark) {
				UpdateAppBar ();
			}  
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}

	void on_focus_in_cb (object o, FocusInEventArgs args)
	{		
		try {
			UpdateAppBar ();
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}

	void on_focus_out_cb (object o, FocusOutEventArgs args)
	{		
		try {				
			Studio.MainAppBar.ClearRowAndColumn ();
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}

	void editor_settings_changed_cb (object obj, NotifyEventArgs args)
	{
		UpdateEditorSettings ();
	}
	
	override public string Path
	{
		set {
			base.Path = value;
			SourceLanguage lang = LanguagesManager_.GetLanguageFromMimeType (MimeTypes.GetMimeType (value));
        		if (lang != null) {
				Buffer.Highlight = true;
				Buffer.Language = lang;
			} else {
			    Buffer.Highlight = false;
			}
		}
	}

	override public string Selection
	{
		get {
			TextIter start, end;
			if (!Buffer.GetSelectionBounds (out start, out end)) {
				return null;
			}
			return Buffer.GetText (start, end, false);			
		}
	}
		
	public bool HasSelection
	{
		get {
			TextIter start, end;
			if (!Buffer.GetSelectionBounds (out start, out end)) {
				return false;
			}
			return start.Offset != end.Offset;
		}
	}
		
	override public Widget TopWidget 
	{
		get {
			return ScrolledWindow_;
		}
	}
		
	override public bool Modified 
	{
		get {
			return Buffer.Modified;
		}
	}

	override public bool HasFocus 
	{
		get {
			return View_.HasFocus;
		}
	}

	SourceBuffer Buffer {
		get {
			return (SourceBuffer)View_.Buffer;
		}
		
		set {
			View_.Buffer = value;
		}
	}
}

}
