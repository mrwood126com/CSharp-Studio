///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.IO;

namespace CSharpStudio {

public class EditProjectDialog : ModalDialog {
	Project Project_;
	Gtk.Notebook Notebook_;

	// General tab
	Gtk.Entry NameEntry_;
	Gnome.FileEntry ProjectTopFolderEntry_;
	Gtk.TextView DescriptionTextView_;

	// Files tab
	Gtk.TextView IncludedFilesTextView_;
	Gtk.TextView ExcludedFilesTextView_;
		
	// Build tab 
	Gnome.FileEntry BuildTopFolderEntry_;
	Gtk.Label CustomBuildLabel_;
	Gtk.CheckButton CustomBuildCheckButton_;
	Gtk.Entry CustomBuildCommandEntry_;
	Gtk.Label CustomBuildCleanLabel_;
	Gtk.CheckButton CustomBuildCleanCheckButton_;
	Gtk.Entry CustomBuildCleanCommandEntry_;

	// Execute tab
	Gnome.FileEntry ExecuteTargetEntry_;
	Gtk.Label CustomExecuteLabel_;
	Gtk.CheckButton CustomExecuteCheckButton_;
	Gtk.Entry CustomExecuteCommandEntry_;

	// Edit tab	
	Gtk.SpinButton TabsWidthSpinButton_;
	Gtk.CheckButton FillTabsCheckButton_;
	
        public EditProjectDialog (Gtk.Window parent, Project project) : base (parent, "edit_project_dialog")
        {
		Project_ 			= project;
		Notebook_			= (Gtk.Notebook)GladeXml_ ["edit_project_dialog_notebook"];
		
		// General tab
		NameEntry_ 		 	= (Gtk.Entry)GladeXml_ ["edit_project_dialog_general_name_entry"];
		ProjectTopFolderEntry_ 	 	= (Gnome.FileEntry)GladeXml_ ["edit_project_dialog_general_top_folder_fileentry"];
		DescriptionTextView_ 	 	= (Gtk.TextView)GladeXml_ ["edit_project_dialog_general_description_textview"];

		// Files tab 
		IncludedFilesTextView_ 	 	= (Gtk.TextView)GladeXml_ ["edit_project_dialog_files_include_textview"];
		ExcludedFilesTextView_ 	 	= (Gtk.TextView)GladeXml_ ["edit_project_dialog_files_exclude_textview"];

		// Build tab
		BuildTopFolderEntry_ 	 	= (Gnome.FileEntry)GladeXml_ ["edit_project_dialog_build_top_folder_fileentry"];
		CustomBuildLabel_ 	 	= (Gtk.Label)GladeXml_ ["edit_project_dialog_build_custom_command_label"];
		CustomBuildCheckButton_  	= (Gtk.CheckButton)GladeXml_ ["edit_project_dialog_build_custom_enabled_checkbutton"];
		CustomBuildCommandEntry_ 	= (Gtk.Entry)GladeXml_ ["edit_project_dialog_build_custom_command_entry"];
		CustomBuildCleanLabel_ 	 	= (Gtk.Label)GladeXml_ ["edit_project_dialog_build_clean_custom_command_label"];
		CustomBuildCleanCheckButton_  	= (Gtk.CheckButton)GladeXml_ ["edit_project_dialog_build_clean_custom_enabled_checkbutton"];
		CustomBuildCleanCommandEntry_ 	= (Gtk.Entry)GladeXml_ ["edit_project_dialog_build_clean_custom_command_entry"];
	
		// Execute tab
		ExecuteTargetEntry_	 	= (Gnome.FileEntry)GladeXml_ ["edit_project_dialog_execute_target_fileentry"];
		CustomExecuteLabel_ 	 	= (Gtk.Label)GladeXml_ ["edit_project_dialog_execute_custom_command_label"];
		CustomExecuteCheckButton_	= (Gtk.CheckButton)GladeXml_ ["edit_project_dialog_execute_custom_enabled_checkbutton"];
		CustomExecuteCommandEntry_ 	= (Gtk.Entry)GladeXml_ ["edit_project_dialog_execute_custom_command_entry"];
		
		// Editor tab	
		TabsWidthSpinButton_ 		= (Gtk.SpinButton)GladeXml_ ["edit_project_dialog_editor_tabs_width_spinbutton"];;
		FillTabsCheckButton_ 		= (Gtk.CheckButton)GladeXml_ ["edit_project_dialog_editor_fill_tabs_checkbutton"];;
	}
	
	protected override bool TransferDataToWindow ()
	{
		// restore the opened page
		Notebook_.CurrentPage 			= Settings.EditProjectDialogTab;
		
		// General tab 
		NameEntry_.Text 			= Project_.Name;
		ProjectTopFolderEntry_.GtkEntry.Text 	= Project_.TopProjectFolder;
		DescriptionTextView_.Buffer.Text 	= Project_.Description;

		// Files tab
		IncludedFilesTextView_.Buffer.Text 	= GetFiles (Project_.IncludedFiles);
		ExcludedFilesTextView_.Buffer.Text 	= GetFiles (Project_.ExcludedFiles);
		
		// Build tab
		BuildTopFolderEntry_.GtkEntry.Text 	= Project_.TopBuildFolder;
		
		CustomBuildCheckButton_.Active 		= Project_.CustomBuildEnabled;
		CustomBuildCommandEntry_.Text 		= Project_.CustomBuildCommand;
		on_custom_build_enabled_toggled_cb (CustomBuildCheckButton_, null);

		CustomBuildCleanCheckButton_.Active 	= Project_.CustomBuildCleanEnabled;
		CustomBuildCleanCommandEntry_.Text 	= Project_.CustomBuildCleanCommand;
		on_custom_build_clean_enabled_toggled_cb (CustomBuildCleanCheckButton_, null);

		// Execute tab
		ExecuteTargetEntry_.GtkEntry.Text 	= Project_.ExecuteTarget;
		CustomExecuteCheckButton_.Active 	= Project_.CustomExecuteEnabled;
		CustomExecuteCommandEntry_.Text 	= Project_.CustomExecuteCommand;
		on_custom_execute_enabled_toggled_cb (CustomExecuteCheckButton_, null);
		
		// Editor tab
		TabsWidthSpinButton_.Value 		= Project_.TabsWidth;
		FillTabsCheckButton_.Active 		= Project_.FillTabs;

		return true;
	}
	
	protected override bool TransferDataFromWindow ()
	{
		if (!ValidateGeneralTab ()) {
			Notebook_.CurrentPage = 0;
			return false;
		}
		if (!ValidateFilesTab ()) {
			Notebook_.CurrentPage = 1;
			return false;
		}
		if (!ValidateBuildTab ()) {
			Notebook_.CurrentPage = 2;
			return false;
		}
		if (!ValidateExecuteTab ()) {
			Notebook_.CurrentPage = 3;
			return false;
		}
		if (!ValidateEditorTab ()) {
			Notebook_.CurrentPage = 3;
			return false;
		}
		
		// everything is ok
		Project project = new Project ();
		
		// remember current page
		Settings.EditProjectDialogTab 		= Notebook_.CurrentPage;

		// General tab
		project.Name 				= NameEntry_.Text.Trim ();
		project.TopProjectFolder		= ProjectTopFolderEntry_.GtkEntry.Text;
		project.Filename 			= Project_.Filename; // we don't allow to change project filename from here
		project.Description 			= DescriptionTextView_.Buffer.Text;

		// Files tab
		project.IncludedFiles 			= GetFiles (IncludedFilesTextView_.Buffer.Text);
		project.ExcludedFiles 			= GetFiles (ExcludedFilesTextView_.Buffer.Text);

		// Build tab
		project.TopBuildFolder 			= BuildTopFolderEntry_.GtkEntry.Text.Trim ();
		project.CustomBuildEnabled 		= CustomBuildCheckButton_.Active;
		project.CustomBuildCommand 		= CustomBuildCommandEntry_.Text.Trim ();
		project.CustomBuildCleanEnabled 	= CustomBuildCleanCheckButton_.Active;
		project.CustomBuildCleanCommand 	= CustomBuildCleanCommandEntry_.Text.Trim ();

		// Execute tab
		project.ExecuteTarget 			= ExecuteTargetEntry_.GtkEntry.Text.Trim ();
		project.CustomExecuteEnabled 		= CustomExecuteCheckButton_.Active;
		project.CustomExecuteCommand 		= CustomExecuteCommandEntry_.Text.Trim ();

		// Editor tab
		project.TabsWidth 			= Convert.ToUInt32 (TabsWidthSpinButton_.Value);
		project.FillTabs 			= FillTabsCheckButton_.Active;

		// remember the project
		Project_ = project;
		return true;
	}
	
	protected bool ValidateGeneralTab ()
	{
		if (NameEntry_.Text.Trim () == String.Empty) {
			ShowError ("The project name could not be empty.");
			return false;
		}

		string topFolder = ProjectTopFolderEntry_.GtkEntry.Text;
		if (topFolder == String.Empty) {
			ShowError ("The top project folder could not be empty.");
			return false;
		} else {
			DirectoryInfo di = new DirectoryInfo (topFolder);
			if (!di.Exists) {
				ShowError ("The top project folder must exist and be a folder.");
				return false;
			}
		}
		
		return true;
	}
	
	bool ValidateFilesTab ()
	{
		return true;
	}

	bool ValidateBuildTab ()
	{
		string topFolder = BuildTopFolderEntry_.GtkEntry.Text.Trim ();
		if (topFolder == String.Empty) {
			ShowError ("The top build folder could not be empty.");
		} else {
			DirectoryInfo di = new DirectoryInfo (topFolder);
			if (!di.Exists) {
				ShowError ("The top build folder must exist and be a folder.");
				return false;
			}
		}
		if (CustomBuildCheckButton_.Active && CustomBuildCommandEntry_.Text.Trim () == String.Empty) {
			ShowError ("Custom build command is not specified.");
			return false;
		}

		if (CustomBuildCleanCheckButton_.Active && CustomBuildCleanCommandEntry_.Text.Trim () == String.Empty) {
			ShowError ("Custom clean command is not specified.");
			return false;
		}
		
		return true;
	}

	bool ValidateExecuteTab ()
	{
		if (ExecuteTargetEntry_.GtkEntry.Text.Trim () == String.Empty) {
			ShowError ("The execute target could not be empty.");
			return false;
    		}

		if (CustomExecuteCheckButton_.Active && CustomExecuteCommandEntry_.Text.Trim () == String.Empty) {
			ShowError ("Custom execute command is not specified.");
			return false;
		}

		return true;
	}

	bool ValidateEditorTab ()
	{
		return true;
	}
	
	string[] GetFiles (string str)
	{
		return str.Split (new Char[] {'\n'}, 1024);
	}
	
	string GetFiles (string[] list)
	{
		string res = "";
		for (int i = 0; i < list.Length; i++) {
			if (list [i] != String.Empty) {
				res += list[i] + "\n";
			}
		}
		return res;
	}
	
	public void on_custom_build_enabled_toggled_cb (object o, EventArgs args)
	{
		try {
			CustomBuildLabel_.Sensitive		= CustomBuildCheckButton_.Active;
			CustomBuildCommandEntry_.Sensitive 	= CustomBuildCheckButton_.Active;
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
	}

	public void on_custom_build_clean_enabled_toggled_cb (object o, EventArgs args)
	{
		try {
			CustomBuildCleanLabel_.Sensitive	= CustomBuildCleanCheckButton_.Active;
			CustomBuildCleanCommandEntry_.Sensitive = CustomBuildCleanCheckButton_.Active;
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
	}

	public void on_custom_execute_enabled_toggled_cb (object o, EventArgs args)
	{
		try {
			CustomExecuteLabel_.Sensitive		= CustomExecuteCheckButton_.Active;
			CustomExecuteCommandEntry_.Sensitive 	= CustomExecuteCheckButton_.Active;
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
	}
	
	public Project Project {	
		get {
			return Project_;
		}
	}
}

}
