///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using GConf;
using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.Collections;
using System.IO;

namespace CSharpStudio {

public class MainMenu {
	static string RecentListMenuItemName = "recent-list-menu-item-name";
	static string RecentListMenuItemPath = "recent-list-menu-item-path";
	
	Glade.XML GladeXml_ = null;
	MenuBar MenuBar_ = null;
	MenuItem RecentFilesMenuItem_;
	MenuItem RecentProjectsMenuItem_;

	Hashtable Menus_;
	
        public MainMenu (MenuBar menu)
        {
		MenuBar_ = menu;
		GladeXml_ = Glade.XML.GetWidgetTree (MenuBar_);
		RecentFilesMenuItem_ = (MenuItem) GladeXml_ ["file_recent"]; 
		RecentProjectsMenuItem_ = (MenuItem) GladeXml_ ["project_recent"];
		Menus_ = new Hashtable ();		
		Menus_ [String.Empty] = GladeXml_;
		
		CreateRecentFilesMenu ();
		CreateRecentProjectsMenu ();
		Settings.AddRecentItemsListChangedHandler (Settings.RecentFilesListName, 
				new NotifyEventHandler (recent_files_list_changed_cb));
		Settings.AddRecentItemsListChangedHandler (Settings.RecentProjectsListName, 
				new NotifyEventHandler (recent_projects_list_changed_cb));
	}
	
	public void RegisterPopupMenu (string name, object obj)
	{
		Glade.XML gxml = new Glade.XML (Defines.GladeFile, name, null);
		gxml.Autoconnect (obj);
		RegisterPopupMenu (name, gxml);
	}
	
	public void RegisterPopupMenu (string name, Glade.XML gxml)
	{
		Menus_ [name] = gxml;
	}
	
	public Menu GetPopupMenu (string name)
	{
		Glade.XML gxml = (Glade.XML) Menus_ [name];
		return (Menu)gxml [name];
	}

	public void ShowItem (string name, bool show) 
	{
		IDictionaryEnumerator e = Menus_.GetEnumerator ();
		while (e.MoveNext ()) {
			try {
				MenuItem item = (MenuItem) ((Glade.XML)e.Value) [name];
				if (item.Visible != show) {
					item.Visible = show;
				}
			} catch (Exception ex) {
				// we don't care!
			}
		}
	}	
	
	public void EnableItem (string name, bool enable) 
	{
		IDictionaryEnumerator e = Menus_.GetEnumerator ();
		while (e.MoveNext ()) {
			try {
				MenuItem item = (MenuItem) ((Glade.XML)e.Value) [name];
				if (item.Sensitive != enable) {
					item.Sensitive = enable;
				}
			} catch (Exception ex) {
				// we don't care!
			}
		}
	}

	public void ActivateItem (string name, bool activate) 
	{
		IDictionaryEnumerator e = Menus_.GetEnumerator ();
		while (e.MoveNext ()) {
			try {
				CheckMenuItem item = (CheckMenuItem) ((Glade.XML)e.Value) [name];
				if (item.Active != activate) {
					item.Active = activate;
				}
			} catch (Exception ex) {
				// we don't care!
			}
		}
	}

	public bool IsItemActive (string name) 
	{
		return IsItemActive (GladeXml_, name);
	}

	public bool IsItemActive (string popup, string name) 
	{
		Glade.XML gxml = (Glade.XML) Menus_ [popup];
		return IsItemActive (gxml, name);
	}

	bool IsItemActive (Glade.XML gxml, string name) 
	{	
		CheckMenuItem item = (CheckMenuItem) gxml [name];
		return item.Active;
	}
	
	void CreateRecentFilesMenu ()
	{
		CreateRecentListMenu (Settings.RecentFilesListName, RecentFilesMenuItem_);
	}
	
	void CreateRecentProjectsMenu ()
	{
		CreateRecentListMenu (Settings.RecentProjectsListName, RecentProjectsMenuItem_);
	}

	void CreateRecentListMenu (string name, MenuItem parent)
	{
		string [] items = Settings.GetRecentItemsList (name);
		Menu menu = new Menu ();
		int i;
		
		for (i = 0; i < items.Length; i++) {
			if (items [i] == null || items [i] == String.Empty) {
				break;
			}
			string menuName = String.Format ("_{0}. {1}", i, Path.GetFileName (items [i]));
			// Console.WriteLine ("CreateRecentListMenu ({0}): {1}", name, menuName);
			MenuItem menuItem = new MenuItem (menuName);
			menuItem.Data [RecentListMenuItemName] = name;
			menuItem.Data [RecentListMenuItemPath] = items [i];
			menuItem.Activated += new EventHandler (recent_list_item_activated_cb);
			menuItem.Visible = true;
			menu.Append (menuItem);
		}
		parent.Submenu = menu;
		parent.Visible = i > 0;
		menu.Visible = i > 0;
	}
	
	void recent_files_list_changed_cb (object obj, NotifyEventArgs args)
	{
		// Console.WriteLine ("recent_files_list_changed_cb");
		try {
			CreateRecentFilesMenu ();
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}

	void recent_projects_list_changed_cb (object obj, NotifyEventArgs args)
	{
		// Console.WriteLine ("recent_projects_list_changed_cb");
		try {
			CreateRecentProjectsMenu ();
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}

	void recent_list_item_activated_cb (object obj, EventArgs args)
	{
		MenuItem menuItem = obj as MenuItem;
		if (menuItem != null) {
			// Console.WriteLine ("recent_list_item_activated_cb");
			string name = (string)menuItem.Data [RecentListMenuItemName];
			string path = (string)menuItem.Data [RecentListMenuItemPath];
			
			if (name == Settings.RecentFilesListName) {
				Studio.OpenFile (path);
			} else if (name == Settings.RecentProjectsListName) {
				Studio.OpenProject (path);
			}
		}
	}
}

}
