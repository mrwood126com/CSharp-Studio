///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.Collections;
using System.IO;

namespace CSharpStudio {

public class ProjectFilesView : ProjectView {
	TreeView View_;
	TreeViewColumn ViewColumn_ = null;
	TreePath Selected_ = null;
	
	ProjectFile ProjectRoot_ = null;
	Hashtable Folders_ = null;
	
	Gdk.Pixbuf ProjectPixbuf_;
	Gdk.Pixbuf FolderPixbuf_;
	Gdk.Pixbuf FilePixbuf_;
	
        public ProjectFilesView (TreeView view)
        {
		View_ = view;
		
		ProjectPixbuf_ = View_.RenderIcon (Gtk.Stock.Home, IconSize.Menu, View_.Name);
		FolderPixbuf_ = View_.RenderIcon (Gtk.Stock.Open, IconSize.Menu, View_.Name);
		FilePixbuf_ = View_.RenderIcon (Gtk.Stock.Dnd, IconSize.Menu, View_.Name);

		View_.HeadersVisible = false;
		View_.RowCollapsed += new RowCollapsedHandler (on_row_collapsed_cb);
		View_.RowExpanded += new RowExpandedHandler (on_row_expanded_cb);
	}
	
	TreeStore CreateTreeStore ()
	{
		TreeStore store = new TreeStore (typeof (ProjectFile), typeof (string));
		// by some reasons the custom sort function does not work very well:
		// it just crashes :( thus we use a workaround (see AddRow() function for details).
		// store.SetDefaultSortFunc (new TreeIterCompareFunc (tree_iterator_compare_cb), IntPtr.Zero, null);
		store.SetSortColumnId (1, SortType.Ascending);
		return store;
	}
    	
	void CreateColumns () 
	{	
		if (ViewColumn_ == null) {
			ViewColumn_ = new TreeViewColumn ();
			ViewColumn_.Title = "Name";
		
			CellRendererPixbuf pixbufRenderer = new CellRendererPixbuf ();
			ViewColumn_.PackStart (pixbufRenderer, false);
			ViewColumn_.SetCellDataFunc (pixbufRenderer, new TreeCellDataFunc (set_cell_data_icon_cb));
		
			CellRendererText textRenderer = new CellRendererText ();
			ViewColumn_.PackStart (textRenderer, true);
			ViewColumn_.SetCellDataFunc (textRenderer, new TreeCellDataFunc (set_cell_data_filename_cb)); 
		} else {
			View_.RemoveColumn (ViewColumn_);
		}
		View_.AppendColumn (ViewColumn_);
		
	}

	public ProjectFile GetItem (TreeIter iter)
	{
		return (ProjectFile)((TreeStore)View_.Model).GetValue (iter, 0);
	}

	public ProjectFile GetItem (TreePath path)
	{
		TreeIter iter;
		if (!((TreeStore)View_.Model).GetIter (out iter, path)) {
			return null;
		}
		return GetItem (iter);
	}

	TreeRowReference AddRow (TreeRowReference reference, ProjectFile file)
	{
		TreeStore store =  (TreeStore)View_.Model;
		TreeIter iter;

		// by some reasons the custom sort function does not work very well:
		// it just crashes :( thus we use a workaround: long names
		// that have file type prefix. The "D" prefix stands for 
		// directories, "F" prefix is for files. Standard string
		// sort function gives us correct sorting: folders first, files next :)
		string long_name = String.Format ( (file.IsFolder) ? "D:{0}" : "F:{0}", file.FullPath); 
		if (reference != null) {
			TreeIter parent;
			store.GetIter (out parent, reference.Path);
			iter = store.AppendValues (parent, file, long_name);
		} else {
			iter = store.AppendValues (file, long_name);
		}
		TreeRowReference res = new TreeRowReference (store, store.GetPath (iter));
		if (file.IsFolder) {
			Folders_ [file.FullPath] = res;
		}
		return res;
	}
	
	void set_cell_data_icon_cb (TreeViewColumn column, CellRenderer cell, TreeModel model, TreeIter iter)
	{
		try {
			ProjectFile file = GetItem (iter);
			if (file.FullPath == String.Empty) {
				((CellRendererPixbuf)cell).Pixbuf = ProjectPixbuf_;
			} else if (file.IsFolder) {
				((CellRendererPixbuf)cell).Pixbuf = FolderPixbuf_;
			} else {
				// todo: different pixbuf for source files
				((CellRendererPixbuf)cell).Pixbuf = FilePixbuf_;
			}
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
	}

	void set_cell_data_filename_cb (TreeViewColumn column, CellRenderer cell, TreeModel model, TreeIter iter)
	{
		try {
			ProjectFile file = GetItem (iter);
			((CellRendererText)cell).Text = file.Name;
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}		
	}

	void on_row_collapsed_cb (object o, RowCollapsedArgs args)
	{
		try {
			ProjectFile file = GetItem (args.Iter);
			Studio.Project.SetProjectFolderExpandedStatus (file.FullPath, false);
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}

	void on_row_expanded_cb (object o, RowExpandedArgs args)
	{
		try {
			ProjectFile file = GetItem (args.Iter);
			Studio.Project.SetProjectFolderExpandedStatus (file.FullPath, true);
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
		Studio.UpdateUI ();
	}

	public void Clear ()
	{
		View_.Model 	= CreateTreeStore ();
		Folders_ 	= new Hashtable ();

		// add the "Project" root item
		if (Studio.Project != null) {
			// create root item and register it as empty string path and full path
			ProjectRoot_ = new ProjectFile (String.Format ("Project {0}", Studio.Project.Name), String.Empty, null, true);
			Folders_ [Path.GetFullPath (Studio.Project.TopProjectFolder)] = AddRow (null, ProjectRoot_);  
			CreateColumns ();
		} else {
			ProjectRoot_ = null;
		}
	}
	
	public void AddFile (ProjectFile file, ProjectFilesList list)
	{				
		TreeRowReference parent = AddParentFolder (file.Parent, list);
		TreeRowReference reference = AddRow (parent, file);
		if (Studio.Project.GetProjectFolderExpandedStatus (file.Parent)) {
 			View_.ExpandToPath (parent.Path);
		}
	}

	TreeRowReference AddParentFolder (string path, ProjectFilesList list)
	{
		// do we have it already?
		object obj = Folders_ [path];
		if (obj != null) {
			return (TreeRowReference)obj;
		}
		
		// add to the list
		ProjectFile file = list.GetFolder (path);
		return AddRow (AddParentFolder (file.Parent, list), file);
	}
	
	public void ShowPopupMenu (double x, double y)
	{
		TreePath path = null;
		View_.GetPathAtPos ((int)x, (int)y, out path);
		ShowPopupMenu (path, x, y);
	}
	
	public void ShowPopupMenu ()
	{
		TreePath path = Selected; 
		Gdk.Rectangle rect;
		View_.GetCellArea (path, ViewColumn_, out rect);
		ShowPopupMenu (path, rect.x + rect.width / 2, rect.y + rect.height);
	}

	public void ShowPopupMenu (TreePath path, double x, double y)
	{		
		if (path == null) {
			return;
		}
		
		string name;
		ProjectFile file = GetItem (path);
		if (file == null || file.FullPath == String.Empty) {
			name = "project_files_project_popup_menu";
		} else if (file.IsFolder) {
			name = "project_files_folder_popup_menu";
		} else {
			name = "project_files_file_popup_menu";
		}		
		Menu menu = Studio.MainMenu.GetPopupMenu (name);
		menu.Popup (null, null, null, IntPtr.Zero, 0, Gtk.Global.CurrentEventTime);	
	}
	
	void tree_selection_for_each_get_selection (TreeModel model, TreePath path, TreeIter iter)
	{
		Selected_ = path.Copy ();
	}
	
	public TreePath Selected {
		get {
			Selected_ = null;
			View_.Selection.SelectedForeach (new TreeSelectionForeachFunc (tree_selection_for_each_get_selection));
			return Selected_;
		}
	}
	
	public ProjectFile SelectedFile {
		get {
			TreePath path = Selected;
			return (path != null) ? GetItem (path) : null;
		}
	}
}
}

