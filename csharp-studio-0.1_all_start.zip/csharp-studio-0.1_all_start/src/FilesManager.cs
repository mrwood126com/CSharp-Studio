///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using GConf;
using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.Collections;
using System.IO;

namespace CSharpStudio {

public class FilesManager {
	Notebook Notebook_ = null;
	ArrayList Views_ = null;
	
        public FilesManager (Notebook notebook) 
        {
		Notebook_ = notebook;
		Views_ = new ArrayList ();
		Settings.EditorSettingsChanged += new NotifyEventHandler (editor_settings_changed_cb);
		
		// delete the original Glade page		
		Notebook_.RemovePage (0);
		OpenFile (String.Empty);
	}

	public void ReloadProject (bool reloadFiles) 
	{
		for (int i = 0; i < Views_.Count; i++) {
			FileView view = (FileView)Views_[i];
			view.ReloadProject ();
		}
		if (reloadFiles && Studio.Project != null) {
			OpenFiles (Studio.Project.OpenedFiles);
		}
	}	

	public void UpdateUI ()
	{
		FileView view = Current;
	
		// file menus
		Studio.MainMenu.EnableItem ("file_save", view != null && view.Modified);
		Studio.MainMenu.EnableItem ("file_save_as", view != null);

		Studio.MainMenu.EnableItem ("file_print", view != null && false); // todo: print support
		Studio.MainMenu.EnableItem ("file_print_setup", view != null && false); // todo: print support
		Studio.MainMenu.EnableItem ("file_close", view != null);
		
		Studio.MainToolbar.EnableItem ("save_button", view != null && view.Modified);
		Studio.MainToolbar.EnableItem ("print_button", false); // todo: print support

		// edit menus
		if (view != null && view.HasFocus) {
			view.UpdateUI();
		}
		
		// windows menu
		Studio.MainMenu.EnableItem ("windows_next", true); // todo: fix when we upgrade gtk-sharp (get_n_pages)
		Studio.MainMenu.EnableItem ("windows_prev", Notebook_.CurrentPage > 0);
		Studio.MainMenu.EnableItem ("windows_close", view != null);

		// todo: fix when we upgrade gtk-sharp (get_n_pages)
		if (view != null) {
			Studio.MainMenu.ShowItem ("windows_separator1", true);
			// todo: add windows list here
		} else {
			// todo: remove windows list here
			Studio.MainMenu.ShowItem ("windows_separator1", false);
		}
	}

	public void GotoLine (string path, int line)
	{
		OpenFile (path);
		if (Current != null) {
			Current.GotoLine (line);
		}
	}	

	public void OpenFile (string path)
	{
		try {
			if (path != null && path != String.Empty) {
				for (int i = 0; i < Views_.Count; i++) {
					if (((FileView)Views_[i]).Path == path) {
						Notebook_.CurrentPage = i;
						return;
					}
				}
			}
		
			// if the last view is empty, re-use it
			FileView view;
			if (Views_.Count > 0) {
				view = (FileView)Views_[Views_.Count - 1];
				if (!view.Modified && (view.Path == null || view.Path == String.Empty)) {
					view.OpenFile (path);
					if (Studio.Project != null) {
						Studio.Project.OpenedFiles = OpenedFiles;
					}
					return;
				}
			}
		
			// Add View		
			view = new SourceFileView (); // todo: view by file type
			if (path != null && path != String.Empty) {
    				view.OpenFile (path);
				Settings.LastOpenedFile = path;
			}
			Views_.Add (view);
			view.TopWidget.ShowAll ();
			view.Title.ShowAll ();
			
			Notebook_.AppendPage (view.TopWidget, view.Title);
			Notebook_.CurrentPage = Views_.Count - 1;
			if (!Notebook_.Visible) {
				Notebook_.Visible = true;
			}
			if (Studio.Project != null) {
				Studio.Project.OpenedFiles = OpenedFiles;
			}
		} catch (FileNotFoundException exception) {
			Studio.ShowError (exception.Message);
		} catch (System.UnauthorizedAccessException exception) {
			Studio.ShowError (exception.Message);
		}
	}
	
	public void OpenFile ()
	{
		FileSelectionDialog dialog = new FileSelectionDialog (Studio.MainWindow, "Open File", 
							    	      FileAccess.Read, Settings.LastOpenedFile);
		dialog.SelectMultiple = false;
		if (dialog.Run () != ResponseType.Ok) {
			return;
		}	
		OpenFile (dialog.Filename);
	}

	public void OpenFiles (string[] files)
	{
		for (int i = 0; i < files.Length; i++) {
			try {
				OpenFile (files [i]);
    			} catch (System.IO.FileNotFoundException exception) {
				Studio.ShowError (exception.Message);
			} catch (System.UnauthorizedAccessException exception) {
				Studio.ShowError (exception.Message);
			} catch (Exception exception) {
				Studio.ShowExceptionError (exception);
			}
		}		
	}
	
	public bool SaveFile () 
	{
		return SaveFile (Current, false);
	}

	public bool SaveAsFile () 
	{
		return SaveFile (Current, true);
	}

	public bool SaveAll (bool ask) 
	{
		for (int i = 0; i < Views_.Count; i++) {
			FileView view = (FileView)Views_[i];
			Console.WriteLine ("SaveAll: {0}", view.Path);
			if (view.Modified && !SaveFile (view, ask)) {    
				return false;
			}
		}
		return true;
	}
	
	bool SaveFile (FileView view, bool ask) {
		string path = view.Path;
		if (ask && (path == null || path == String.Empty)) {
			FileSelectionDialog dialog = new FileSelectionDialog (Studio.MainWindow, "Save File", 
										FileAccess.Write, "");
			// todo: set folder from LastOpenedFile
			if (dialog.Run () != ResponseType.Ok) {
				return false;
			}

			FileInfo fi = new FileInfo (dialog.Filename);
			if (view.Path != path && fi.Exists) {
				MessageDialog msgDialog = new MessageDialog (Studio.MainWindow, DialogFlags.DestroyWithParent, 
						    MessageType.Warning, ButtonsType.YesNo, 
						    "The file already exists. Overwrite?");
				if ((ResponseType)msgDialog.Run () != ResponseType.Yes) {
					msgDialog.Destroy ();
					return false;
				}	
				msgDialog.Destroy ();
			}		
			
			path = dialog.Filename;
		}

		view.SaveFile (path);
		return true;
	}
	
	public bool CloseFile ()
	{
		return CloseFile (Current, true);
	}
	public bool CloseAllFiles ()
	{
		return CloseAllFiles (true);
	}
	
	bool CloseAllFiles (bool updateProject)
	{
		while (Current != null) {
			if (!CloseFile (Current, false)) {
				return false;
			}
		}
		return true;
	}

	bool CloseFile (FileView view, bool updateProject)
	{
		 if (view.Modified) {
			YesNoCancelDialog dialog = new YesNoCancelDialog (Studio.MainWindow, "The file is not saved. Save before closing?", "File is not saved");
			switch (dialog.Run ()) {
				case ResponseType.Yes:
					if (!SaveFile (view, false)) {
						return false;
					}
					break;
				case ResponseType.No:
					break;
				default:
					return false;
			}			
		}
		Views_.RemoveAt (Notebook_.CurrentPage);
		Notebook_.RemovePage (Notebook_.CurrentPage);
		
		if (updateProject && Studio.Project != null) {
			Studio.Project.OpenedFiles = OpenedFiles;
		}
		return true;
	}
	
	public void Copy (Clipboard clipboard) 
	{
		if (HasFocus) {
			Current.Copy (clipboard);
		}
	}

	public void Cut (Clipboard clipboard) 
	{
		if (HasFocus) {
			Current.Cut (clipboard);
		}
	}

	public void Paste (Clipboard clipboard) 
	{
		if (HasFocus) {
			Current.Paste (clipboard);
		}
	}
	
	public void Clear ()
	{
		if (HasFocus) {
			Current.Clear ();
		}
	}

	public void Undo ()
	{
		if (HasFocus) {
			Current.Undo ();
		}
	}

	public void Redo ()
	{
		if (HasFocus) {
			Current.Redo ();
		}
	}
	
	public void Next ()
	{
		Notebook_.NextPage ();
	}

	public void Prev ()
	{
		Notebook_.PrevPage ();
	}
	
	void editor_settings_changed_cb (object obj, NotifyEventArgs args)
	{
		Studio.UpdateUI ();
	}
		
	public FileView Current 
	{
		get {
			if (Notebook_.CurrentPage < 0 || Notebook_.CurrentPage >= Views_.Count) {
				return null;
			}
			return (Notebook_.CurrentPage >= 0) ? (FileView)Views_ [Notebook_.CurrentPage] : null;
		}
	}

	public bool Modified 
	{
		get {
			for (int i = 0; i < Views_.Count; i++) {
				if (((FileView)Views_[i]).Modified) {
					return true;
				}
			}
			return false;
		}
	}
	
	public bool HasFocus {
		get {
			return Current != null && Current.HasFocus;
		}
	}
	
	public string[] OpenedFiles {
		get {
			string[] res = new string [Views_.Count];
			for (int i = 0; i < Views_.Count; i++) {
				res [i] = ((FileView)Views_[i]).Path;
			}
			return res;
		}
	}

}

}
