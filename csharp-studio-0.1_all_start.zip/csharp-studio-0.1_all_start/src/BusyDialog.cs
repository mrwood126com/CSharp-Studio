///////////////////////////////////////////////////////////////////////////
// 
// C# Studio
//
// This is free software; see Copyright file in the source
// distribution for preciese wording.
// 
// Copyright (C) 2003 Aleksey Sanin <aleksey@aleksey.com>
//
///////////////////////////////////////////////////////////////////////////

using Gtk;
using Gdk;
using GtkSharp;
using Gnome;
using Glade;
using System;
using System.IO;

namespace CSharpStudio {

public class BusyDialog {
	bool Canceled_ = false;
	Glade.XML GladeXml_;
	Dialog Dialog_;
	Gtk.Label MessageLabel_;
	
        public BusyDialog (Gtk.Window parent)
        {
		GladeXml_ 	= new Glade.XML (Defines.GladeFile, "busy_dialog", null);
		Dialog_ 	= (Dialog) GladeXml_ ["busy_dialog"];
		MessageLabel_ 	= (Gtk.Label) GladeXml_ ["busy_dialog_message_label"];
		GladeXml_.Autoconnect (this);
	}
	
	public void Start ()
	{
		Canceled_ = false;
		Update (String.Empty);
		Dialog_.Show ();
	}
	
	public void Update (string format, params object[] args)
	{
		if (format != String.Empty) {
			MessageLabel_.Text = String.Format (format, args);
		} else {
			MessageLabel_.Text = String.Empty;
		}
		Dialog_.WindowPosition = WindowPosition.CenterOnParent;

		// we need to update our data
		while (Application.EventsPending ()) {
			Application.RunIteration ();
		}
	}

	public void on_response_cb (object o, ResponseArgs args)
	{
		try {
			Canceled_ = true;
			Dialog_.Hide ();
		} catch (Exception exception) {
			Studio.ShowExceptionError (exception);
		}
    	}
	
	public void Finish ()
	{
		Dialog_.Hide ();
	}

	public bool Canceled 
	{
		get {
			return Canceled_;
		}
	}
}
}
