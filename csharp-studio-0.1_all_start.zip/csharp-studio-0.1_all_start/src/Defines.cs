using System;
using System.IO;

namespace CSharpStudio
{
	class Defines
	{
		public static string Package 		= "csharp-studio";
		public static string PackageTitle 	= "C# Studio";
		public static string Version 		= "0.1";
		public static string Prefix 		= "/home/aleksey";
		public static string DataDir 		= "/home/aleksey/share/csharp-studio";

#if CSHARP_STUDIO_USE_LOCAL_RESOURCES
		static string SourcePath		= Path.Combine ("/home/aleksey/dev/tmp/ss/src", "..");
		static string PixmapsDirPath		= Path.Combine (Defines.SourcePath, "pixmaps");
		static string SrcDirPath		= Path.Combine (Defines.SourcePath, "src");
		public static string GuiDir 		= PixmapsDirPath;
		public static string GladeFile 		= Path.Combine (SrcDirPath, "csharp-studio.glade");
		public static string RcFile 		= Path.Combine (SrcDirPath, "csharp-studio.rc");
#else
		public static string GuiDir		= "/home/aleksey/share/csharp-studio/gui";
		public static string GladeFile 		= Path.Combine (GuiDir, "csharp-studio.glade");
		public static string RcFile 		= Path.Combine (GuiDir, "csharp-studio.rc");
#endif		
		
		static public string GetPixmapFile (string name)
		{
			return Path.Combine (GuiDir, name);
		}
	}
}

